class t {
    constructor() {}
    static t(t, e, a) {
        var r = fetch(t, {
            headers: e
        }).then(t => t.json().then(e => ({
            ok: t.ok,
            status: t.status,
            url: t.url,
            headers: t.headers,
            json: e
        })));
        return a instanceof Function && r.then(t => a(t)), r;
    }
    static o(t, e, a) {
        navigator.permissions.query({
            name: "clipboard-write"
        }).then(t => {
            if ("granted" === t.state) {
                var e = new Blob([ "hello" ], {
                    type: "text/plain"
                }), r = new ClipboardItem({
                    "text/plain": e
                });
                navigator.clipboard.write([ r ]).then((function() {
                    a("");
                }), (function(t) {
                    a("unable to write to clipboard. Error:", t);
                }));
            } else a("clipboard-permissoin not granted: " + t);
        });
    }
    static i(t, e, a) {
        var r = "";
        for (let e = 0; e < t.length; e++) {
            r = r + t[e] + "\n";
        }
        e.writeText(r).then(() => {
            a("");
        }).catch(t => {
            a(t);
        });
    }
    static s(e, a, r) {
        var n = Date.now(), o = r + "\n" + n + "\n" + t.u(e) + "\n" + a + "\nonlyfans";
        return {
            sign: this.l(o),
            time: n,
            accept: "application/json, text/plain, */*",
            "access-token": r
        };
    }
    static p(t) {
        try {
            return t.split("/").pop().split("?")[0];
        } catch (t) {
            return "";
        }
    }
    static u(t) {
        return t = t.replace(/^.*\/\/[^\/]+/, "");
    }
    static v() {
        var t = new Date, e = "" + (t.getMonth() + 1), a = "" + t.getDate(), r = t.getFullYear();
        return e.length < 2 && (e = "0" + e), a.length < 2 && (a = "0" + a), [ r, e, a ].join("-");
    }
    static m(t) {
        1 == t.split("T").length && (t += "T00:00:00");
        var e = new Date(t), a = e.getMonth() + 1;
        a < 10 && (a = "0" + a);
        e.getDate();
        return e.getFullYear() + "-" + a + "-" + e.getDate();
    }
    static g(t) {
        1 == t.split("T").length && (t += "T00:00:00");
        var e = new Date(t), a = e.getMonth() + 1;
        a < 10 && (a = "0" + a);
        var r = e.getDate();
        return r < 10 && (r = "0" + r), e.getFullYear() + "-" + a + "-" + e.getDate();
    }
    static D(t) {
        1 == t.split("T").length && (t += "T00:00:00");
        var e = new Date(t), a = e.getMonth() + 1;
        a < 10 && (a = "0" + a);
        var r = e.getDate();
        r < 10 && (r = "0" + r);
        var n = e.getHours();
        n < 10 && (n = "0" + n);
        var o = e.getMinutes();
        o < 10 && (o = "0" + o);
        var i = e.getSeconds();
        return i < 10 && (i = "0" + i), e.getFullYear() + "-" + a + "-" + r + "T" + n + ":" + o + ":" + i;
    }
    static T(t, e) {
        t = this.D(t), e.includes("es") || e.includes("en") || (e = "en-US"), e = "es-CH";
        try {
            var a = new Date(t);
            return a.toLocaleDateString(e, {
                month: "2-digit",
                day: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit"
            });
        } catch (t) {
            return "";
        }
    }
    static h(t, e) {
        var a = t.createElement("BUTTON");
        a.setAttribute("class", "ofx-regular-button");
        var r = t.createElement("p"), n = t.createTextNode(e);
        return r.appendChild(n), a.appendChild(r), a;
    }
    static L(t) {
        var e = document.createElement("label");
        e.setAttribute("class", "g-input__label"), e.setAttribute("class", "g-input__label");
        var a = document.createTextNode(t);
        return e.appendChild(a), e;
    }
    static F(t, e) {
        const a = document.createElement("option");
        a.disabled = true;
        const r = document.createTextNode(t);
        return a.appendChild(r), a.setAttribute("value", e), a;
    }
    static U(t) {
        var e = document.createElement("input");
        return e.setAttribute("type", "date"), e.setAttribute("class", "g-input form-control"), 
        e.setAttribute("id", t), e;
    }
    static k(t) {
        var e = new Date(t), a = "" + (e.getMonth() + 1), r = "" + e.getDate(), n = e.getFullYear();
        return a.length < 2 && (a = "0" + a), r.length < 2 && (r = "0" + r), [ n, a, r ].join("-");
    }
    static C(t) {
        try {
            var e = t.split("T"), a = e[0].split("-"), r = e[1].split(":");
            return a.push.apply(a, r), Date.UTC(a) / 1000 + ".000000";
        } catch (t) {
            return "";
        }
    }
    static I(t) {
        return new Date(1000 * t);
    }
    static S(t) {
        return new Date(t).getTime() / 1000 + ".000000";
    }
    static l(t) {
        var e, a, r, n, o, i = [], c = [ a = 0x67452301, r = 0xefcdab89, ~a, ~r, 0xc3d2e1f0 ], s = [], u = unescape(encodeURI(t)) + "", l = u.length;
        for (s[t = --l / 4 + 2 | 15] = 8 * l; ~l; ) s[l >> 2] |= u.charCodeAt(l) << 8 * ~l--;
        for (e = l = 0; e < t; e += 16) {
            for (a = c; l < 80; a = [ a[4] + (i[l] = l < 16 ? ~~s[e + l] : 2 * u | u < 0) + 1518500249 + [ r & n | ~r & o, u = 341275144 + (r ^ n ^ o), 882459459 + (r & n | r & o | n & o), u + 1535694389 ][l++ / 5 >> 2] + ((u = a[0]) << 5 | u >>> 27), u, r << 30 | r >>> 2, n, o ]) u = i[l - 3] ^ i[l - 8] ^ i[l - 14] ^ i[l - 16], 
            r = a[1], n = a[2], o = a[3];
            for (l = 5; l; ) c[--l] += a[l];
        }
        for (u = ""; l < 40; ) u += (c[l >> 3] >> 4 * (7 - l++) & 15).toString(16);
        return u;
    }
}