function tt(t, n, o) {
    return "content" != t.to || ("popup" === t.from ? ot(t, n, o) : "background" == t.from && nt(t, n, o), 
    true);
}

function nt(t, n, o) {
    var c;
    "logged_out" == t.subject ? (pt && lt(), c = "") : "logged_in" == t.subject && (pt || vt(), 
    c = ""), o instanceof Function && o(c);
}

function ot(t, n, o) {}

function ct(t, n) {
    var o, c = [];
    for (let e = 0; e < t.length; e++) {
        const u = t[e];
        (o = new Object).url = u.url, o.path = n + "/" + u.type + "/", o.filename = u.url.substring(u.url.lastIndexOf("/") + 1, u.url.lastIndexOf("?") + 0), 
        c.push(o);
    }
    var e = {
        from: "content",
        to: "background",
        subject: "downloadFiles"
    };
    e.payload = [ c ], chrome.runtime.sendMessage(e, (function() {}));
}

async function et() {
    var t = {
        from: "content",
        to: "background",
        subject: "getSession",
        payload: []
    };
    chrome.runtime.sendMessage(t, (function(t) {
        pt = t.imLoggedIn;
    }));
}

function ut() {
    if (document.body && document.head) {
        document.body.addEventListener("__HTTPRESPONSE__", t => {
            it(t);
        });
        var t = chrome.runtime.getURL("./js/injection.js"), n = document.createElement("script");
        n.src = t, document.head.prepend(n), n.parentNode.removeChild(n);
    }
}

function rt(t) {
    var n = "", o = t.getElementsByClassName("g-user-username");
    return o && o[0] && (n = o[0].innerText) && n.length > 0 && "@" == n.charAt(0) && (n = n.slice(1)), 
    n;
}

function it(t) {
    var n = {}, o = t.detail.response, c = t.detail.status, e = t.detail.url;
    gt = new URL(e).searchParams.get("app-token"), e.includes("logout") && 200 == c ? lt() : e.includes("login") && c >= 200 && c < 400 ? vt() : pt && (!e.includes("posts") || e.includes("paid") || e.includes("comments") ? e.includes("posts") && e.includes("paid") && !e.includes("comments") ? setTimeout((function() {
        mt(st(o), 1);
    }), 1000) : !e.includes("/v2/users") || e.includes("/v2/users/customer") || "object" != typeof o || Array.isArray(o) ? e.includes("/v2/users/customer") : o.id && (200 == c && true == o.subscribedBy ? ((n = {}).from = "content", 
    n.to = "background", n.subject = "newSubscription", n.payload = [ o.id, o.username, o.name ], 
    chrome.runtime.sendMessage(n, (function() {}))) : 200 == c && true != o.subscribedBy && ((n = {}).from = "content", 
    n.to = "background", n.subject = "newUnsubscription", n.payload = [ o.username ], 
    chrome.runtime.sendMessage(n, (function() {})))) : setTimeout((function() {
        mt(st(o), 1);
    }), 500));
}

function st(t) {
    Array.isArray(t) || t.constructor != Object || (t = [ t ]);
    var n = {}, o = {};
    for (let e = 0; e < t.length; e++) {
        const u = t[e];
        o = new Object;
        var c = u.author && u.author.id || u.fromUser && u.fromUser.id;
        o = {
            id: u.id,
            userId: c,
            media: u.media
        }, n[u.id] = o;
    }
    return n;
}

function at(n, o, c) {
    var e, u = "", r = 0, i = false, s = document.createElement("div"), a = [];
    for (let n = 0; n < c.length; n++) {
        const f = c[n];
        i = true, f.canView && (f.url = f.source.source, a.push(f.url), u = "Xtract " + f.type, 
        (e = t.h(document, u)).addEventListener("click", (function() {
            ct([ f ], o);
        })), s.appendChild(e), r++);
    }
    i && (n.id = "PROCESSED"), r > 1 && (u = "Xtract ALL", (e = t.h(document, u)).addEventListener("click", (function() {
        ct(c, o);
    })), s.appendChild(e)), r > 0 && (u = "Xtract links", (e = t.h(document, u)).addEventListener("click", (function() {
        dt(a);
    })), s.appendChild(e)), n.appendChild(s);
}

function ft(t, n) {
    try {
        var o = document.getElementById("ofx_snackbar");
        o.innerText = t;
        var c = "";
        c = "SUCCESS" == n.toUpperCase() ? "show-success" : "show-error", o.className = c, 
        setTimeout((function() {
            o.className = o.className.replace(c, "");
        }), 3000);
    } catch (t) {}
}

function dt(n) {
    t.i(n, navigator.clipboard, (function(t) {
        "" == t ? ft("Links copied to clipboard!", "success") : ft("Couldn't copy links to clipboard :(", "error");
    }));
}

function mt(t, n) {
    if (!(n > 50)) try {
        var o, c, e = document.getElementsByClassName("b-post");
        if (e && e.length > 0) {
            for (let n = 0; n < e.length; n++) {
                const r = e[n];
                if ("PROCESSED" != r.id) if (c = r.id.split("_")[1], o = rt(r), t[c] && t[c].media) {
                    var u = t[c].media;
                    o && u && u.length > 0 && at(r, o, u), delete t[c];
                } else delete t[c];
            }
            Object.keys(t).length > 0 && setTimeout((function() {
                n++, mt(t, n);
            }), 1500);
        } else "loading" == document.readyState && setTimeout((function() {
            n++, mt(t, n);
        }), 1500);
    } catch (t) {}
}

function lt() {
    pt = false, gt = "", bt = [], _users = [];
}

function vt() {
    pt = true, gt = "", bt = [], et();
}

chrome.runtime.onMessage.addListener(tt);

var bt = [], pt = false, gt = "";

document.addEventListener("DOMContentLoaded", (function(t) {
    et(), ut();
    var n = document.createElement("div");
    n.setAttribute("id", "ofx_snackbar"), n.innerText = "", document.body.appendChild(n);
}));