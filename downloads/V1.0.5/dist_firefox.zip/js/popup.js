function e(e, o, t) {
    var n, c = [];
    for (let t = 0; t < e.length; t++) {
        const a = e[t];
        (n = new Object).url = a.url, n.path = o + "/" + a.type + "/", n.filename = a.url.substring(a.url.lastIndexOf("/") + 1, a.url.lastIndexOf("?") + 0), 
        c.push(n);
    }
    var a = {
        from: "popup",
        to: "background",
        subject: "downloadFiles"
    };
    a.payload = [ c ], chrome.runtime.sendMessage(a, (function() {}));
}

function o(o, n) {
    try {
        var c;
        if ("posts" == o) c = document.getElementsByName("checkboxDownloadPostMedia"); else if ("chats" == o) c = document.getElementsByName("checkboxDownloadChatMedia"); else {
            if ("stories" != o) return;
            c = document.getElementsByName("checkboxDownloadStoryMedia");
        }
        for (var a, s = P(), i = [], r = [], u = 0; u < c.length; u++) {
            var d;
            if (c[u].checked) if ("undefined" != (a = c[u].id)) "posts" == o ? d = s.ts(a) : "chats" == o ? d = s.ss(a) : "stories" == o && (d = s.es(a)), 
            i.push(d), r.push(d.url);
        }
        i.length <= 0 ? G("No items selected") : "DOWNLOAD" == n.toUpperCase() ? e(i, s.ft(), n) : "CLIPBOARD" == n.toUpperCase() && t.i(r, navigator.clipboard, (function(e) {
            "" == e ? K("success", "Selected links copied to clipboard!") : G("Error: " + e);
        }));
    } catch (e) {}
}

function n(e) {
    var o = {
        photo: 0,
        video: 0,
        audio: 0
    };
    try {
        var n, s, i, r = document.getElementById("postsTable");
        r = r.getElementsByTagName("tbody")[0];
        var u, d = e.Et(), l = -1, h = -1, m = 1;
        for (let e = 0; e < d.length; e++) {
            const p = d[e];
            if (l = p.postId, h = e + 1 < d.length ? d[e + 1].postId : -1, "audio" == p.type ? (n = "../images/audio.png", 
            s = "../images/audio.png") : "photo" == p.type ? (n = p.thumb, s = p.thumb) : "video" == p.type && (n = p.thumb, 
            s = p.preview), p.canViewMedia && p.hasMedia) {
                try {
                    var v = p.type;
                    o[v] || (o[v] = 0), o[v]++;
                } catch (e) {}
                i = t.T(p.postedAt, window.navigator.language);
                var f = a(p.id, n, s, p.type, p.duration, i, p.rawText, m), b = document.createElement("tr");
                b.innerHTML = f, r.appendChild(b), 1 == m && (u = b), h == l ? m++ : (c(u, "rowspanColumn", m), 
                m = 1);
            }
        }
    } catch (e) {}
    return o;
}

function c(e, o, t) {
    var n = e.getElementsByClassName(o);
    for (let e = 0; e < n.length; e++) {
        n[e].rowSpan = t;
    }
}

function a(e, o, t, n, c, a, s, i) {
    var r, u, d = "";
    "photo" == n ? (r = "photos-svg", u = "Photo") : "video" == n ? (r = "videos-svg", 
    u = "Video", d = `<div class="media-length-container">\n    <label class="media-length">\n    <svg class="g-icon" viewBox="0 2 23 23">\n      <use xlink:href="./icons.svg#videos-svg" />\n    </svg> | ${c = new Date(1000 * c).toISOString().substr(11, 8)}\n    </label>\n  </div>`) : "audio" == n ? (r = "audios-svg", 
    u = "Audio", d = `<div class="media-length-container">\n    <label class="media-length">\n    <svg class="g-icon" viewBox="0 2 23 23">\n      <use xlink:href="./icons.svg#audios-svg" />\n    </svg> | ${c = new Date(1000 * c).toISOString().substr(11, 8)}\n    </label>\n  </div>`) : (r = "posts-svg", 
    u = "Text only");
    var l = `\n  <td><input type="checkbox" id="${e}" name="checkboxDownloadPostMedia"></td>\n  <td>\n    <div class="hover_img div_center">\n      <a href="#"><img class="thumbnail" src="${o}" alt=" " />\n          <span><img class="hidden-image" src="${t}" alt="image"  /></span>\n      </a>\n      ${d}\n    </div>\n\n  </td>\n  <td>\n    <svg class="g-icon" viewBox="0 2 23 23">\n        <use xlink:href="./icons.svg#${r}" />\n        <title>${u}</title>\n    </svg>\n    \n  </td>\n  <td>${a}</td>\n`;
    return 1 == i && (l += `<td rowspan=1 class="rowspanColumn">${s}</td>`), l;
}

function i(e, o, t, n, c, a, s, i, r) {
    var u, d, l = "";
    return "photo" == n ? (u = "photos-svg", d = "Photo") : "video" == n ? (u = "videos-svg", 
    d = "Video", l = `<div class="media-length-container">\n    <label class="media-length">\n    <svg class="g-icon" viewBox="0 2 23 23">\n    <use xlink:href="./icons.svg#videos-svg" />\n  </svg> | ${i = new Date(1000 * i).toISOString().substr(11, 8)}\n    </label>\n  </div>`) : "audio" == n ? (u = "audios-svg", 
    d = "Audio") : (u = "posts-svg", d = "Text only"), `\n  <td><input type="checkbox" id="${e}" data-type="${n}" data-username="${r}" data-source="${s}" name="checkboxDownloadPurchasedMedia"></td>\n  <td>\n    <div class="hover_img div_center">\n      <a href="#"><img class="thumbnail" src="${o}" alt=" " />\n          <span><img class="hidden-image" src="${t}" alt="image"  /></span>\n      </a>\n      ${l}\n    </div>\n\n  </td>\n  <td>\n  <svg class="g-icon" viewBox="0 2 23 23">\n  <use xlink:href="./icons.svg#${u}" />\n  <title>${d}</title>\n</svg>\n  </td>\n  <td>@${r}</td>\n  <td>${c}</td>\n  <td>${a}</td>\n`;
}

function r(e, o, t, n, c, a, s, i) {
    var r, u, d = "";
    "photo" == n ? (r = "photos-svg", u = "Photo") : "video" == n ? (r = "videos-svg", 
    u = "Video", d = `<div class="media-length-container">\n    <label class="media-length">\n    <svg class="g-icon" viewBox="0 2 23 23">\n    <use xlink:href="./icons.svg#videos-svg" />\n  </svg> | ${c = new Date(1000 * c).toISOString().substr(11, 8)}\n    </label>\n  </div>`) : "audio" == n ? (r = "audios-svg", 
    u = "Audio") : (r = "posts-svg", u = "Text only");
    var l = `\n  <td><input type="checkbox" id="${e}" name="checkboxDownloadChatMedia"></td>\n  <td>\n    <div class="hover_img div_center">\n      <a href="#"><img class="thumbnail" src="${o}" alt=" " />\n          <span><img class="hidden-image" src="${t}" alt="image"  /></span>\n      </a>\n      ${d}\n    </div>\n\n  </td>\n  <td>\n  <svg class="g-icon" viewBox="0 2 23 23">\n  <use xlink:href="./icons.svg#${r}" />\n  <title>${u}</title>\n</svg>\n  </td>\n  <td>${a}</td>\n  \n`;
    return 1 == i && (l += `<td rowspan=1 class="rowspanColumn">${s}</td>`), l;
}

function u(e, o, t, n, c, a, s) {
    var i, r, u = "";
    return "photo" == n ? (i = "photos-svg", r = "Photo") : "video" == n ? (i = "videos-svg", 
    r = "Video", u = `<div class="media-length-container">\n    <label class="media-length">\n    <svg class="g-icon" viewBox="0 2 23 23">\n    <use xlink:href="./icons.svg#videos-svg" />\n  </svg> | ${c = new Date(1000 * c).toISOString().substr(11, 8)}\n    </label>\n  </div>`) : "audio" == n ? (i = "audios-svg", 
    r = "Audio") : (i = "posts-svg", r = "Text only"), `\n  <td><input type="checkbox" id="${e}" name="checkboxDownloadStoryMedia"></td>\n  <td>\n    <div class="hover_img div_center">\n      <a href="#"><img class="thumbnail" src="${o}" alt=" " />\n          <span><img class="hidden-image" src="${t}" alt="image"  /></span>\n      </a>\n      ${u}\n    </div>\n\n  </td>\n  <td>\n  <svg class="g-icon" viewBox="0 2 23 23">\n  <use xlink:href="./icons.svg#${i}" />\n  <title>${r}</title>\n</svg>\n  </td>\n  <td>${a}</td>\n`;
}

function d(e, o, t) {
    try {
        q();
        var c = P();
        c.us(e, o, t, (function(e, o) {
            try {
                0 == c.Et().length && K("error", "Nothing found!"), M("postsTable"), y("checkboxSelectPhotosPosts"), 
                y("checkboxSelectVideosPosts"), y("postsSelectAll"), p("posts", n(c)), document.getElementById("postsTableControlContainer").style.display = "block";
            } catch (e) {} finally {
                J();
            }
        }));
    } catch (e) {
        J();
    }
}

function l(e) {
    var o = {
        photo: 0,
        video: 0,
        audio: 0
    };
    try {
        var n, a, s, i = document.getElementById("chatsTable");
        i = i.getElementsByTagName("tbody")[0];
        var u, d = e.Ht(), l = -1, h = -1, m = 1;
        for (let e = 0; e < d.length; e++) {
            const p = d[e];
            if (l = p.dmId, h = e + 1 < d.length ? d[e + 1].dmId : -1, "audio" == p.type ? (n = "../images/audio.png", 
            a = "../images/audio.png") : "photo" == p.type ? (n = p.thumb, a = p.thumb) : "video" == p.type && (n = p.thumb, 
            a = p.preview), p.canViewMedia) if (p.hasMedia) {
                try {
                    var v = p.type;
                    o[v] || (o[v] = 0), o[v]++;
                } catch (e) {}
                s = t.T(p.postedAt, window.navigator.language);
                var f = r(p.id, n, a, p.type, p.duration, s, p.rawText, m), b = document.createElement("tr");
                b.innerHTML = f, i.appendChild(b), 1 == m && (u = b), h == l ? m++ : (c(u, "rowspanColumn", m), 
                m = 1);
            } else n = "../images/nomedia.png", a = "../images/nomedia.png";
        }
    } catch (e) {}
    return o;
}

function h(e) {
    var o = {
        photo: 0,
        video: 0,
        audio: 0
    };
    try {
        var n, c, a, s = document.getElementById("storiesTable");
        s = s.getElementsByTagName("tbody")[0];
        var i = e.Wt();
        for (let e = 0; e < i.length; e++) {
            const h = i[e];
            "audio" == h.type ? (n = "../images/audio.png", c = "../images/audio.png") : "photo" == h.type ? (n = h.thumb, 
            c = h.thumb) : "video" == h.type && (n = h.thumb, c = h.preview);
            try {
                var r = h.type;
                o[r] || (o[r] = 0), o[r]++;
            } catch (e) {}
            a = t.T(h.postedAt, window.navigator.language);
            var d = u(h.id, n, c, h.type, h.duration, a, h.rawText), l = document.createElement("tr");
            l.innerHTML = d, s.appendChild(l);
        }
    } catch (e) {}
    return o;
}

function m(e, o) {
    try {
        q();
        var t = P();
        t.cs(e, o, (function(e, o) {
            try {
                0 == t.Ht().length && 0 == t.Ct().length && K("error", "Nothing found!"), M("chatsTable"), 
                y("checkboxSelectPhotosChats"), y("checkboxSelectVideosChats"), y("chatsSelectAll"), 
                p("chats", l(t)), document.getElementById("chatsTableControlContainer").style.display = "block";
            } catch (e) {} finally {
                J();
            }
        }));
    } catch (e) {
        J();
    }
}

function v(e) {
    var o = {
        photo: 0,
        video: 0,
        audio: 0
    };
    try {
        var n, c, a, s = document.getElementById("purchasesTable");
        s = s.getElementsByTagName("tbody")[0];
        for (let l = 0; l < e.length; l++) {
            const h = e[l];
            "audio" == h.type ? (n = "../images/audio.png", c = "../images/audio.png") : "photo" == h.type ? (n = h.thumb, 
            c = h.thumb) : "video" == h.type && (n = h.thumb, c = h.preview);
            try {
                var r = h.type;
                o[r] || (o[r] = 0), o[r]++;
            } catch (e) {}
            a = t.T(h.postedAt, window.navigator.language);
            var u = i(h.id, n, c, h.type, a, h.rawText, h.source.source, h.duration, h.purchasedFrom.username), d = document.createElement("tr");
            d.innerHTML = u, s.appendChild(d);
        }
    } catch (e) {}
    return o;
}

function f(o) {
    try {
        var n;
        n = document.getElementsByName("checkboxDownloadPurchasedMedia");
        for (var c = {}, a = [], s = 0, i = 0; i < n.length; i++) if (n[i].checked) {
            s++;
            var r = n[i].getAttribute("data-source"), u = n[i].getAttribute("data-type"), d = n[i].getAttribute("data-username");
            c[d] || (c[d] = []);
            var l = new Object;
            l.url = r, l.type = u, "DOWNLOAD" == o.toUpperCase() ? c[d].push(l) : "CLIPBOARD" == o.toUpperCase() && a.push(l.url);
        }
        if (s <= 0) G("No items selected"); else if ("DOWNLOAD" == o.toUpperCase()) for (const o in c) {
            e(c[o], o);
        } else "CLIPBOARD" == o.toUpperCase() && t.i(a, navigator.clipboard, (function(e) {
            "" == e ? K("success", "Selected links copied to clipboard!") : G("Error: " + e);
        }));
    } catch (e) {}
}

function b() {
    try {
        var e = W.appToken, o = W.useragent, t = W.cookie;
        L = [], q(), document.getElementById("checkboxSelectPhotosPurchases").checked = false, 
        document.getElementById("checkboxSelectVideosPurchases").checked = false, document.getElementById("purchasesSelectAll").checked = false, 
        s.as(e, t, o, (function(e, o, t) {
            if (e) {
                L = t;
                try {
                    0 == L.length && K("error", "Nothing found!"), M("purchasesTable"), y("checkboxSelectPhotosPurchases"), 
                    y("checkboxSelectVideosPurchases"), y("purchasesSelectAll"), p("purchases", v(L)), 
                    document.getElementById("purchasesTableControlContainer").style.display = "block";
                } catch (e) {} finally {
                    J();
                }
            } else L = [];
        }));
    } catch (e) {}
}

function p(e, o) {
    switch (e.toUpperCase()) {
      case "PURCHASES":
        document.getElementById("tablePurchasesPhotosCount").innerText = o.photo, document.getElementById("tablePurchasesVideosCount").innerText = o.video, 
        document.getElementById("tablePurchasesAudiosCount").innerText = o.audio;
        break;

      case "POSTS":
        document.getElementById("tablePostsPhotosCount").innerText = o.photo, document.getElementById("tablePostsVideosCount").innerText = o.video, 
        document.getElementById("tablePostsAudiosCount").innerText = o.audio;
        break;

      case "CHATS":
        document.getElementById("tableChatsPhotosCount").innerText = o.photo, document.getElementById("tableChatsVideosCount").innerText = o.video, 
        document.getElementById("tableChatsAudiosCount").innerText = o.audio;
        break;

      case "STORIES":
        document.getElementById("tableStoriesPhotosCount").innerText = o.photo, document.getElementById("tableStoriesVideosCount").innerText = o.video, 
        document.getElementById("tableStoriesAudiosCount").innerText = o.audio;
    }
}

function g() {
    try {
        q();
        var e = P();
        e.ls((function(o, t) {
            try {
                0 == e.Wt().length && K("error", "Nothing found!"), M("storiesTable"), y("checkboxSelectPhotosStories"), 
                y("checkboxSelectVideosStories"), y("storiesSelectAll"), p("stories", h(e)), document.getElementById("storiesTableControlContainer").style.display = "block";
            } catch (e) {} finally {
                J();
            }
        }));
    } catch (e) {
        J();
    }
}

function S(e) {
    if (W.imLoggedIn && W.cookie && W.useragent && W.appToken) {
        var o = [];
        try {
            q("Getting your subscriptions..."), s.et(W.cookie, W.useragent, W.appToken, (function(t) {
                if (Array.isArray(t)) {
                    for (let e = 0; e < t.length; e++) {
                        const n = t[e];
                        o.push(n.It()), s.ot(N, n);
                    }
                    Promise.all(o).then(o => {
                        try {
                            e(o);
                        } catch (e) {} finally {
                            J();
                        }
                    });
                } else G("Error trying to retrieve user list");
            }));
        } catch (e) {
            J(), G(e);
        }
    }
}

function k(e) {
    var o = {
        from: "popup",
        to: "background",
        subject: "getSessionParams"
    };
    chrome.runtime.sendMessage(o, (function(o) {
        try {
            var t = o[0];
            W.cookie = t.sescookie, W.useragent = t.useragent, W.appToken = t.appToken, W.imLoggedIn = t.imLoggedIn, 
            e instanceof Function && e(W);
        } catch (e) {}
    }));
}

function w(e) {
    var o = {
        from: "popup",
        to: "background",
        subject: "getUserList",
        payload: []
    };
    chrome.runtime.sendMessage(o, (function(o) {
        N = [];
        var t = o[0], n = o[1];
        if (t) {
            for (let e = 0; e < n.length; e++) {
                const o = n[e];
                var c = s.rs(o);
                c.Rt() || N.push(c);
            }
            N.sort((function(e, o) {
                return e.ft() < o.ft() ? -1 : e.ft() > o.ft() ? 1 : 0;
            })), e instanceof Function && e([ t, N ]);
        } else e([ t, [] ]);
    }));
}

function P() {
    try {
        var e = document.getElementById("usersSelect"), o = e[e.selectedIndex].value;
        return s.Lt(N, o);
    } catch (e) {
        return;
    }
}

function x(e) {
    return t.T(e, window.navigator.language).split(" ")[0];
}

function C() {
    var e = P(), o = x(e.Jt());
    M("postsTable"), M("chatsTable"), M("storiesTable"), U({
        joinedAtValue: o,
        postsValue: e.Kt(),
        photosValue: e.qt(),
        videosValue: e.zt(),
        audiosValue: e.Gt(),
        archivedValue: e.Qt(),
        hasStoriesValue: e.Zt()
    }), V("show"), A("posts"), document.getElementById("postsTableControlContainer").style.display = "none", 
    document.getElementById("chatsTableControlContainer").style.display = "none", document.getElementById("storiesTableControlContainer").style.display = "none";
    var t = document.getElementById("userProfilePicture");
    e.jt() && "" != e.jt() ? t.src = e.jt() : t.src = "../images/no_picture_available.jpg", 
    document.getElementById("regularPosts").checked = true;
    var n = document.getElementById("customSearch");
    n.checked = true, n.click();
    var c = document.getElementById("customSearchChats");
    c.checked = true, c.click(), y("checkboxSelectPhotosPosts"), y("checkboxSelectVideosPosts"), 
    y("postsSelectAll"), y("checkboxSelectPhotosChats"), y("checkboxSelectPhotosChats"), 
    y("chatsSelectAll"), y("checkboxSelectPhotosStories"), y("checkboxSelectPhotosStories"), 
    y("storiesSelectAll"), y("checkboxSelectPhotosPurchases"), y("checkboxSelectPhotosPurchases"), 
    y("purchasesSelectAll");
}

function y(e) {
    var o = document.getElementById(e);
    o && (o.checked = false);
}

function T(e, o) {
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, (function(t) {
        chrome.tabs.sendMessage(t[0].id, e, (function(e) {
            o(e);
        }));
    }));
}

function D() {
    k((function() {})), I(), $(), w((function(e) {
        N.length > 0 && F(N);
    }));
}

function $() {
    M("postsTable"), M("chatsTable"), M("storiesTable"), M("purchasesTable"), document.getElementById("purchasesTableControlContainer").style.display = "none", 
    F([]), U({
        joinedAtValue: "N/A",
        postsValue: 0,
        photosValue: 0,
        videosValue: 0,
        audiosValue: 0,
        archivedValue: 0,
        hasStoriesValue: "--"
    }), V("hide"), A("topTabContentHome"), A("noTab"), document.getElementById("userProfilePicture").src = "../images/no_picture_available.jpg";
}

function A(e) {
    var o = "";
    switch (e) {
      case "posts":
        o = "btnPosts";
        break;

      case "chats":
        o = "btnChats";
        break;

      case "about":
        break;

      case "noTab":
        o = "btnNoTab";
        break;

      case "topTabContentHome":
        o = "topBtnHome";
        break;

      case "topTabContentPurchases":
        o = "topBtnPurchases";
        break;

      case "topTabContentAbout":
        o = "topBtnAbout";
    }
    var t = document.getElementById(o);
    t && t.click();
}

function V(e) {
    B("buttonGroupWrapper", e), B("buttonGroupWrapperChats", e);
}

function B(e, o) {
    var t = document.getElementById(e);
    t && (t.style.display = "hide" === o ? "none" : "block");
}

function U(e) {
    for (var o in e) {
        var t = document.getElementById(o);
        t && (t.innerText = e[o]);
    }
}

function F(e) {
    var o;
    try {
        for (var n = (o = document.getElementById("usersSelect")).getElementsByTagName("option"); n.length > 0; ) n[0].remove();
    } catch (e) {
        return;
    }
    var c = t.F("Select a user", "");
    c.selected = true, c.hidden = true, o.appendChild(c);
    for (let n = 0; n < e.length; n++) {
        const a = e[n];
        (c = t.F(a.Ut() + ` (@${a.ft()})`, a.ft())).disabled = false, o.appendChild(c);
    }
}

function M(e) {
    var o = document.getElementById(e);
    try {
        var t = o.getElementsByTagName("tr");
        if (t && t.length > 1) for (;t.length > 1; ) o.deleteRow(1);
    } catch (e) {}
}

function O(e) {
    var o = document.getElementById("screenCoverContainer");
    document.getElementById("coverText").innerText = e, o.style.display = "block";
}

window.Notiflix.Notify.Init({
    position: "right-bottom",
    cssAnimationStyle: "from-left"
}), window.Notiflix.Loading.Init({
    backgroundColor: "rgba(255, 255, 255, 0.7)",
    fontFamily: "Roboto",
    svgSize: "80px",
    messageFontSize: "18px",
    ee: "#32c682",
    oe: "#959595"
});

var N = [], L = [], W = {
    cookie: "",
    useragent: "",
    appToken: "",
    imLoggedIn: false
};

function _(e, o) {
    document.getElementById(e)._flatpickr.setDate(o, true, "Y-m-d");
}

function j() {
    var e = document.querySelectorAll("input[type=date]");
    for (let o = 0; o < e.length; o++) {
        const t = e[o];
        window.flatpickr("#" + t.id, {
            altInput: true,
            altFormat: "F j, Y",
            dateFormat: "Y-m-d",
            onChange: function(e, o, t) {}
        }), t._flatpickr.altInput.placeholder = "Select date...";
    }
}

function R() {
    W.cookie && W.useragent && W.appToken ? (N = [], S((function(e) {
        var o = {
            from: "popup",
            to: "background",
            subject: "setUserList"
        }, t = [];
        for (let e = 0; e < N.length; e++) {
            const o = N[e];
            t.push(o.Ot());
        }
        o.payload = [ t ], chrome.runtime.sendMessage(o, (function() {})), D();
    }))) : G("Session info missing");
}

function I() {
    document.getElementById("reloadUserList").onclick = function() {
        R();
    }, document.getElementById("topBtnHome").onclick = function() {
        ee(this), X("topTabContentHome");
    }, document.getElementById("topBtnPurchases").onclick = function() {
        ee(this), X("topTabContentPurchases");
    }, document.getElementById("topBtnAbout").onclick = function() {
        ee(this), X("topTabContentAbout");
    }, document.getElementById("btnPosts").onclick = function() {
        Z(this), Q("tabPosts");
    }, document.getElementById("btnChats").onclick = function() {
        Z(this), Q("tabChats");
    }, document.getElementById("btnStories").onclick = function() {
        Z(this), Q("tabStories");
    }, document.getElementById("btnNoTab").onclick = function() {
        Z(this), Q("tabNoTab");
    }, document.getElementById("usersSelect").addEventListener("change", (function() {
        C();
    })), document.getElementById("downloadSelectedChatsButton").onclick = function() {
        o("chats", "download");
    }, document.getElementById("copyLinksSelectedChatsButton").onclick = function() {
        o("chats", "clipboard");
    }, document.getElementById("downloadSelectedStoriesButton").onclick = function() {
        o("stories", "download");
    }, document.getElementById("copyLinksSelectedStoriesButton").onclick = function() {
        o("stories", "clipboard");
    }, document.getElementById("downloadSelectedPurchasesButton").onclick = function() {
        f("download");
    }, document.getElementById("copyLinksSelectedPurchasesButton").onclick = function() {
        f("clipboard");
    }, document.getElementById("downloadSelectedButton").onclick = function() {
        o("posts", "download");
    }, document.getElementById("copyLinksSelectedButton").onclick = function() {
        o("posts", "clipboard");
    }, document.getElementById("searchStories").onclick = function() {
        g();
    }, document.getElementById("searchPurchases").onclick = function() {
        b();
    }, document.getElementById("searchChats").onclick = function() {
        var e = document.getElementById("chatsDateFrom"), o = document.getElementById("chatsDateTo"), t = e.value, n = o.value;
        "" != t && "" != n ? t > n ? G('"Date from" must be less than "date to"') : m(t, n) : G('Please select "date from" and "date to"');
    }, document.getElementById("searchPosts").onclick = function() {
        var e = document.getElementById("postsDateFrom"), o = document.getElementById("postsDateTo"), t = e.value, n = o.value;
        if ("" != t && "" != n) if (t > n) G('"Date from" must be less than "date to"'); else {
            var c = document.getElementsByName("postTypeSearch"), a = "", s = false;
            for (let e = 0; e < c.length; e++) {
                const o = c[e];
                true == o.checked && (a = o.value);
            }
            "regular" == a ? s = false : "archived" == a && (s = true), d(t, n, s);
        } else G('Please select "date from" and "date to"');
    }, document.getElementById("dummy").onclick = function() {
        G("hello");
    }, document.getElementById("purchasesSelectAll").addEventListener("change", (function(e) {
        var o = document.getElementById("checkboxSelectPhotosPurchases"), t = document.getElementById("checkboxSelectVideosPurchases");
        o.checked = e.target.checked, t.checked = e.target.checked;
        for (var n = document.getElementsByName("checkboxDownloadPurchasedMedia"), c = 0; c < n.length; c++) n[c].checked = e.target.checked;
    })), document.getElementById("checkboxSelectPhotosPurchases").addEventListener("change", (function(e) {
        for (var o = document.getElementsByName("checkboxDownloadPurchasedMedia"), t = 0; t < o.length; t++) {
            "photo" == o[t].getAttribute("data-type") && (o[t].checked = e.target.checked);
        }
    })), document.getElementById("checkboxSelectVideosPurchases").addEventListener("change", (function(e) {
        for (var o = document.getElementsByName("checkboxDownloadPurchasedMedia"), t = 0; t < o.length; t++) {
            "video" == o[t].getAttribute("data-type") && (o[t].checked = e.target.checked);
        }
    })), document.getElementById("postsSelectAll").addEventListener("change", (function(e) {
        var o = document.getElementById("checkboxSelectPhotosPosts"), t = document.getElementById("checkboxSelectVideosPosts");
        o.checked = e.target.checked, t.checked = e.target.checked;
        for (var n = document.getElementsByName("checkboxDownloadPostMedia"), c = (P(), 
        0); c < n.length; c++) n[c].checked = e.target.checked;
    })), document.getElementById("checkboxSelectPhotosPosts").addEventListener("change", (function(e) {
        E("photo", e.target.checked, "checkboxDownloadPostMedia");
    })), document.getElementById("checkboxSelectVideosPosts").addEventListener("change", (function(e) {
        E("video", e.target.checked, "checkboxDownloadPostMedia");
    })), document.getElementById("chatsSelectAll").addEventListener("change", (function(e) {
        var o = document.getElementById("checkboxSelectPhotosChats"), t = document.getElementById("checkboxSelectVideosChats");
        o.checked = e.target.checked, t.checked = e.target.checked;
        for (var n = document.getElementsByName("checkboxDownloadChatMedia"), c = (P(), 
        0); c < n.length; c++) n[c].checked = e.target.checked;
    })), document.getElementById("checkboxSelectPhotosChats").addEventListener("change", (function(e) {
        H("photo", e.target.checked, "checkboxDownloadChatMedia");
    })), document.getElementById("checkboxSelectVideosChats").addEventListener("change", (function(e) {
        H("video", e.target.checked, "checkboxDownloadChatMedia");
    })), document.getElementById("storiesSelectAll").addEventListener("change", (function(e) {
        var o = document.getElementById("checkboxSelectPhotosStories"), t = document.getElementById("checkboxSelectVideosStories");
        o.checked = e.target.checked, t.checked = e.target.checked;
        for (var n = document.getElementsByName("checkboxDownloadStoryMedia"), c = 0; c < n.length; c++) n[c].checked = e.target.checked;
    })), document.getElementById("checkboxSelectPhotosStories").addEventListener("change", (function(e) {
        Y("photo", e.target.checked, "checkboxDownloadStoryMedia");
    })), document.getElementById("checkboxSelectVideosStories").addEventListener("change", (function(e) {
        Y("video", e.target.checked, "checkboxDownloadStoryMedia");
    }));
    var e = document.getElementsByName("searchType");
    for (let o = 0; o < e.length; o++) {
        e[o].addEventListener("click", (function(e) {
            "customSearch" == e.target.id && e.target.checked;
            var o = new Date, n = t.k(new Date);
            switch (e.target.id) {
              case "customSearch":
                _("postsDateFrom", ""), _("postsDateTo", n);
                break;

              case "sinceYesterdaySearch":
                o.setDate(o.getDate() - 1), _("postsDateFrom", t.k(o)), _("postsDateTo", n);
                break;

              case "lastWeekSearch":
                o.setDate(o.getDate() - 7), _("postsDateFrom", t.k(o)), _("postsDateTo", n);
                break;

              case "everythingSearch":
                _("postsDateFrom", P().Jt()), _("postsDateTo", n);
            }
        }));
    }
    var n = document.getElementsByName("searchTypeChats");
    for (let e = 0; e < n.length; e++) {
        n[e].addEventListener("click", (function(e) {
            var o = "customSearchChats" == e.target.id && e.target.checked, n = t.k(new Date);
            (_("postsDateTo", n), o) ? (_("chatsDateFrom", ""), _("chatsDateTo", n)) : (_("chatsDateFrom", P().Jt()), 
            _("chatsDateTo", n));
        }));
    }
    document.querySelector(".modal"), document.querySelector(".trigger");
    document.querySelector(".close-button").addEventListener("click", z);
}

function E(e, o, t) {
    for (var n, c = document.getElementsByName(t), a = P(), s = 0; s < c.length; s++) {
        n = c[s].id;
        var i = a.ts(n);
        i && i.type == e && (c[s].checked = o);
    }
}

function H(e, o, t) {
    for (var n, c = document.getElementsByName(t), a = P(), s = 0; s < c.length; s++) {
        n = c[s].id;
        var i = a.ss(n);
        i && i.type == e && (c[s].checked = o);
    }
}

function Y(e, o, t) {
    for (var n, c = document.getElementsByName(t), a = P(), s = 0; s < c.length; s++) {
        n = c[s].id;
        var i = a.es(n);
        i && i.type == e && (c[s].checked = o);
    }
}

function z() {
    document.querySelector(".modal").classList.toggle("show-modal");
}

function G(e) {
    window.Notiflix.Report.Failure("", e, "Ok", (function() {}), {
        width: "360px",
        svgSize: "50px",
        messageFontSize: "2.5rem"
    });
}

function q(e) {
    var o = "Wait...";
    e && (o = e), window.Notiflix.Loading.Dots(o);
}

function J() {
    window.Notiflix.Loading.Remove();
}

function K(e, o) {
    var t = "";
    switch (e.toUpperCase()) {
      case "ERROR":
        t = "Failure";
        break;

      case "SUCCESS":
        t = "Success";
        break;

      case "WARNING":
        t = "Warning";
        break;

      case "INFO":
      default:
        t = "Info";
    }
    window.Notiflix.Notify[t](o);
}

function Q(e) {
    var o = document.getElementsByName("tab-content"), t = document.getElementById(e);
    for (let e = 0; e < o.length; e++) {
        o[e].style.display = "none";
    }
    t.style.display = "block";
}

function X(e) {
    var o = document.getElementsByName("topTabContent"), t = document.getElementById(e);
    for (let e = 0; e < o.length; e++) {
        o[e].style.display = "none";
    }
    t.style.display = "block";
}

function Z(e) {
    var o = document.getElementsByName("tabButton");
    for (let e = 0; e < o.length; e++) {
        o[e].classList.remove("active");
    }
    e.classList.add("active");
}

function ee(e) {
    var o = document.getElementsByName("topTabButton");
    for (let e = 0; e < o.length; e++) {
        o[e].classList.remove("top-tab-button-active");
    }
    e.classList.add("top-tab-button-active");
}

document.addEventListener("DOMContentLoaded", (function(e) {
    j(), chrome.tabs.query({
        active: true,
        currentWindow: true
    }, (function(e) {
        e[0].url.includes("onlyfans.com") ? k((function(e) {
            w((function(o) {
                var t = o[0];
                if (t) D(); else if (e.imLoggedIn) {
                    if (!t && e.imLoggedIn) {
                        if (!W.cookie || !W.useragent || !W.appToken) return void O("We are still retrieving info from OnlyFans, please come back in a few seconds...");
                        R();
                    }
                } else I(), $(), O("You are NOT! logged in to OnlyFans, please sign in and then come back...");
            }));
        })) : (I(), $(), O("Please click on the extension button from the tab where OnlyFans.com is open"));
    }));
})), window.onload = function() {};