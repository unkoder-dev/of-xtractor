function ne() {
    if ("undefined" != typeof chrome) return "undefined" != typeof browser ? browser : chrome;
}

var oe = ne();

function te(e, n, o) {
    var t = {
        from: "background"
    };
    t.to = o, t.subject = e, t.payload = n, chrome.tabs.query({
        url: "*://*.onlyfans.com/*"
    }, (function(e) {
        for (let n of e) chrome.tabs.sendMessage(n.id, t, (function(e) {}));
    }));
}

function ie(e) {
    if (!(e.length <= 0)) {
        var n = e[0];
        e.shift(), re(n), e.length > 0 && setTimeout(() => {
            ie(e);
        }, 400);
    }
}

function re(e) {
    chrome.storage.sync.get({
        ne: true
    }, (function(n) {
        if (n.ne) {
            var o = e.path + e.filename;
            chrome.downloads.download({
                url: e.url,
                filename: o,
                conflictAction: "uniquify",
                saveAs: false
            });
        } else chrome.downloads.download({
            url: e.url,
            conflictAction: "uniquify",
            saveAs: false
        });
    }));
}

function se(e) {
    if (!(e.length <= 0)) {
        var n = e[0];
        e.shift(), fe(chrome.downloads, n.url, n.folder, n.type, n.filename);
        e.length > 0 && setTimeout((function() {
            se(e);
        }), 400);
    }
}

function fe(e, n, o, t, i) {
    chrome.storage.sync.get({
        ne: true
    }, (function(r) {
        if (r.ne) {
            var s = o + "/" + t + "/" + i;
            e.download({
                url: n,
                filename: s,
                conflictAction: "uniquify",
                saveAs: false
            });
        } else e.download({
            url: n,
            conflictAction: "uniquify",
            saveAs: false
        });
    }));
}

function ce(e) {
    for (let n = 0; n < ve.length; n++) {
        ve[n].ft() == e && ve.splice(n, 1);
    }
}

function ue(e, n, o) {
    try {
        var t = new s(e, n, o, he, pe, St);
        t.It(), s.ot(ve, t);
    } catch (e) {}
}

function ae(e) {
    for (let o = 0; o < e.length; o++) {
        const t = e[o];
        var n = s.rs(t);
        n.Rt() || s.wt(ve, n);
    }
    de = true;
}

function ot(e, n, o) {
    if ("getUserList" == e.subject) {
        var t = me();
        o([ de, t ]);
    } else "setUserList" == e.subject ? (o(), ae(e.payload[0])) : "downloadFiles" == e.subject ? (o(), 
    ie(e.payload[0])) : "getSessionParams" == e.subject && we(0, (function(e, n, t) {
        var i = {};
        i.sescookie = he, i.useragent = navigator.userAgent, i.appToken = St, i.imLoggedIn = ht, 
        o([ i ]);
    }));
}

function le(e, n, o) {
    if ("downloadFile" == e.subject) {
        var t = e.payload[0], i = e.payload[1], r = e.payload[2], s = t.substring(t.lastIndexOf("/") + 1, t.lastIndexOf("?") + 0);
        return fe(chrome.downloads, t, i, r, s), o && o instanceof Function && o(), true;
    }
    if ("massDownloadFiles" == e.subject) {
        se(e.payload), o instanceof Function && o(resp);
    } else {
        if ("getSession" == e.subject) return we(0, (function(e, n, t) {
            o && o instanceof Function && o({
                imLoggedIn: ht,
                sessCookie: he,
                appToken: St
            });
        })), true;
        if ("getUserList" == e.subject) {
            var f = me();
            o([ de, f ]);
        } else if ("newSubscription" == e.subject) {
            var c = e.payload[0], u = e.payload[1], a = e.payload[2];
            o(), ue(c, u, a);
        } else "newUnsubscription" == e.subject ? (o(), ce(e.payload[0])) : "downloadFiles" == e.subject && (o(), 
        ie(e.payload[0]));
    }
}

function me() {
    var e = [];
    if (de) for (let n = 0; n < ve.length; n++) {
        const o = ve[n];
        e.push(o.Ot());
    }
    return e;
}

function S() {
    if (ht) if (he && pe && St) {
        var e = [];
        s.et(he, pe, St, (function(n) {
            if (Array.isArray(n)) {
                for (let o = 0; o < n.length; o++) {
                    const t = n[o];
                    e.push(t.It()), s.ot(ve, t), de = true;
                }
                Promise.all(e).then(e => {});
            }
        }));
    } else setTimeout(() => {
        S();
    }, 2000);
}

we(0, (function() {})), chrome.webRequest.onBeforeSendHeaders.addListener((function(e) {
    var n = new URL(e.url);
    St = n.searchParams.get("app-token");
}), {
    urls: [ "*://*.onlyfans.com/*" ],
    types: [ "xmlhttprequest" ]
}, [ "requestHeaders" ]), chrome.runtime.onMessage.addListener((e, n, o) => ("background" == !e.to || ("content" === e.from ? le(e, n, o) : "popup" == e.from && ot(e, n, o)), 
true));

var ve = [], de = false, ht = false, St = "", he = "", pe = navigator.userAgent;

function ge() {
    chrome.tabs.query({
        url: "*://*.onlyfans.com/*"
    }, (function(e) {
        for (let n of e) chrome.tabs.reload(n.id);
    })), we(0, (function() {
        ht && S();
    }));
}

function we(e, n) {
    chrome.cookies.getAll({
        url: "https://www.onlyfans.com"
    }, (function(e) {
        var o = false;
        for (let n = 0; n < e.length; n++) {
            const t = e[n];
            "auth_id" == t.name && (o = true, ht = true), "sess" == t.name && (he = t.value);
        }
        n instanceof Function && n(ht, he, St), o || (ht = false);
    })), e > 0 && setTimeout((function() {
        we(e, n);
    }), e);
}

chrome.runtime.onInstalled.addListener(ge), chrome.cookies.onChanged.addListener((function(e) {
    var n = e.cookie.name, o = e.cookie.value, t = e.cause, i = e.removed;
    "auth_id" != n || !i || "expired_overwrite" != t && "explicit" != t ? "auth_id" != n || i || "explicit" != t || ht ? "sess" != n || i || (he = o) : (ht = true, 
    ve = [], de = false, we(0, (function(e, n, o) {
        var t = {
            imLoggedIn: e,
            sessCookie: n,
            appToken: o,
            userAgent: navigator.userAgent
        };
        S(), te("logged_in", [ t ], "content");
    }))) : (ht = false, ve = [], de = false, te("logged_out", [], "content"));
}));