function tt(t, n, o) {
    return "content" != t.to || ("popup" === t.from ? ot(t, n, o) : "background" == t.from && nt(t, n, o), 
    true);
}

function nt(t, n, o) {
    var e;
    "logged_out" == t.subject ? (ht && pt(), e = "") : "logged_in" == t.subject && (ht || gt(), 
    e = ""), o instanceof Function && o(e);
}

function ot(t, n, o) {}

function et(t, n) {
    var o, e = [];
    for (let c = 0; c < t.length; c++) {
        const r = t[c];
        (o = new Object).url = r.url, o.path = n + "/" + r.type + "/", o.filename = r.url.substring(r.url.lastIndexOf("/") + 1, r.url.lastIndexOf("?") + 0), 
        e.push(o);
    }
    var c = {
        from: "content",
        to: "background",
        subject: "downloadFiles"
    };
    c.payload = [ e ], chrome.runtime.sendMessage(c, (function() {}));
}

async function ct() {
    var t = {
        from: "content",
        to: "background",
        subject: "getSession",
        payload: []
    };
    chrome.runtime.sendMessage(t, (function(t) {
        ht = t.imLoggedIn;
    }));
}

function rt() {
    if (document.body && document.head) {
        document.body.addEventListener("__HTTPRESPONSE__", t => {
            it(t);
        });
        var t = chrome.runtime.getURL("./js/injection.js"), n = document.createElement("script");
        n.src = t, document.head.prepend(n), n.parentNode.removeChild(n);
    }
}

function ut(t) {
    var n = "", o = t.getElementsByClassName("g-user-username");
    return o && o[0] && (n = o[0].innerText) && n.length > 0 && "@" == n.charAt(0) && (n = n.slice(1)), 
    n;
}

function it(t) {
    var n = {}, o = t.detail.response, e = t.detail.status, c = t.detail.url;
    St = new URL(c).searchParams.get("app-token"), c.includes("logout") && 200 == e ? pt() : c.includes("login") && e >= 200 && e < 400 ? gt() : ht && (!c.includes("posts") || c.includes("paid") || c.includes("comments") ? c.includes("posts") && c.includes("paid") && !c.includes("comments") ? setTimeout((function() {
        mt(st(o), 1);
    }), 1000) : c.includes("chats") && c.includes("messages") ? setTimeout((function() {
        var t = [];
        if (o.list && Array.isArray(o.list)) {
            for (let n = 0; n < o.list.length; n++) {
                const e = o.list[n];
                e.media && Array.isArray(e.media) && e.media.length > 0 && false == e.canPurchase && t.push(e);
            }
            bt(t, 1);
        }
    }), 1000) : !c.includes("/v2/users") || c.includes("/v2/users/customer") || "object" != typeof o || Array.isArray(o) ? c.includes("/v2/users/customer") : o.id && (200 == e && true == o.subscribedBy ? ((n = {}).from = "content", 
    n.to = "background", n.subject = "newSubscription", n.payload = [ o.id, o.username, o.name ], 
    chrome.runtime.sendMessage(n, (function() {}))) : 200 == e && true != o.subscribedBy && ((n = {}).from = "content", 
    n.to = "background", n.subject = "newUnsubscription", n.payload = [ o.username ], 
    chrome.runtime.sendMessage(n, (function() {})))) : setTimeout((function() {
        mt(st(o), 1);
    }), 500));
}

function st(t) {
    Array.isArray(t) || t.constructor != Object || (t = [ t ]);
    var n = {}, o = {};
    for (let c = 0; c < t.length; c++) {
        const r = t[c];
        o = new Object;
        var e = r.author && r.author.id || r.fromUser && r.fromUser.id;
        o = {
            id: r.id,
            userId: e,
            media: r.media
        }, n[r.id] = o;
    }
    return n;
}

function at(n, o, e) {
    var c, r = "", u = 0, i = false, s = document.createElement("div"), a = [];
    for (let n = 0; n < e.length; n++) {
        const f = e[n];
        i = true, f.canView && (f.url = f.source.source, a.push(f.url), r = "Xtract " + f.type, 
        (c = t.h(document, r)).addEventListener("click", (function() {
            et([ f ], o);
        })), s.appendChild(c), u++);
    }
    i && (n.id = "PROCESSED"), u > 1 && (r = "Xtract ALL", (c = t.h(document, r)).addEventListener("click", (function() {
        et(e, o);
    })), s.appendChild(c)), u > 0 && (r = "Xtract links", (c = t.h(document, r)).addEventListener("click", (function() {
        dt(a);
    })), s.appendChild(c)), n.appendChild(s);
}

function ft(t, n) {
    try {
        var o = document.getElementById("ofx_snackbar");
        o.innerText = t;
        var e = "";
        e = "SUCCESS" == n.toUpperCase() ? "show-success" : "show-error", o.className = e, 
        setTimeout((function() {
            o.className = o.className.replace(e, "");
        }), 3000);
    } catch (t) {}
}

function dt(n) {
    t.i(n, navigator.clipboard, (function(t) {
        "" == t ? ft("Links copied to clipboard!", "success") : ft("Couldn't copy links to clipboard :(", "error");
    }));
}

function mt(t, n) {
    if (!(n > 50)) try {
        var o, e, c = document.getElementsByClassName("b-post");
        if (c && c.length > 0) {
            for (let n = 0; n < c.length; n++) {
                const u = c[n];
                if ("PROCESSED" != u.id) if (e = u.id.split("_")[1], o = ut(u), t[e] && t[e].media) {
                    var r = t[e].media;
                    o && r && r.length > 0 && at(u, o, r), delete t[e];
                } else delete t[e];
            }
            Object.keys(t).length > 0 && setTimeout((function() {
                n++, mt(t, n);
            }), 1500);
        } else "loading" == document.readyState && setTimeout((function() {
            n++, mt(t, n);
        }), 1500);
    } catch (t) {}
}

function lt(t, n) {
    var o = false, e = [], c = -1;
    try {
        for (let u = 0; u < t.length; u++) {
            var r = t[u].media;
            for (let t = 0; t < r.length; t++) {
                const e = r[t];
                if (e.preview == n || e.squarePreview == n || e.thumb == n || e.src == n) {
                    o = true;
                    break;
                }
            }
            if (o) {
                e = r, c = u;
                break;
            }
        }
    } catch (t) {}
    return [ c, e ];
}

function vt() {
    var t = document.getElementById("chatUrl");
    if (t && t.href) {
        var n = t.href.split("/");
        return n.length > 0 ? n[n.length - 1] : "unknown_user";
    }
}

function bt(t, n) {
    if (!(n > 50)) {
        try {
            var o, e = document.getElementsByClassName("b-chat__message__media-wrapper");
            if (e && e.length > 0) {
                for (let n = 0; n < e.length; n++) {
                    const a = e[n];
                    if ("PROCESSED" != a.id) {
                        var c = a.getElementsByTagName("img");
                        (!c || c.length <= 0) && (c = a.getElementsByTagName("source"));
                        var r = "", u = [], i = -1, s = [];
                        c && c.length > 0 && (r = c[0].src, i = (u = lt(t, r))[0], s = u[1]), o = vt(), 
                        !s || s.length <= 0 ? (a.id = "PROCESSED") : (at(a, o, s), t.splice(i, 1));
                    }
                }
                t.length > 0 && setTimeout((function() {
                    n++, bt(t, n);
                }), 1500);
            } else "loading" == document.readyState && setTimeout((function() {
                n++, bt(t, n);
            }), 1500);
        } catch (t) {}
    }
}

function pt() {
    ht = false, St = "", kt = [], _users = [];
}

function gt() {
    ht = true, St = "", kt = [], ct();
}

chrome.runtime.onMessage.addListener(tt);

var kt = [], ht = false, St = "";

document.addEventListener("DOMContentLoaded", (function(t) {
    ct(), rt();
    var n = document.createElement("div");
    n.setAttribute("id", "ofx_snackbar"), n.innerText = "", document.body.appendChild(n);
}));