class s {
    constructor(t, s, e, i, r, a) {
        this.A = "https://onlyfans.com/api2/v2/", this.M = t, this.P = s, this._ = e, this.$ = [], 
        this.O = [], this.J = [], this.N = [], this.R = 0, this.V = 0, this.j = 0, this.B = 0, 
        this.H, this.W, this.Y, this.q = false, this.G = false, this.K = "1970-01-01", this.X = 0, 
        this.Z = i, this.tt = r, this.st = a;
    }
    static et(e, i, r, a) {
        if (!e || !i || !r) throw "Session cookie, user agent and appToken needed";
        var o = new URL("https://onlyfans.com/api2/v2/subscriptions/subscribes?offset=0&type=active&limit=100");
        o.searchParams.set("app-token", r);
        var n = t.s(o.href, i, e);
        t.t(o.href, n, (function() {})).then(t => {
            if (a instanceof Function) {
                if (!(t.ok && t.json && Array.isArray(t.json))) throw t;
                var o = [];
                for (let a = 0; a < t.json.length; a++) {
                    const h = t.json[a];
                    var n = new s(h.id, h.username, h.name, e, i, r);
                    h.avatarThumbs && h.avatarThumbs.c50 && n.it(h.avatarThumbs.c50), h.avatarThumbs && h.avatarThumbs.c144 && n.rt(h.avatarThumbs.c144), 
                    h.avatar && n.at(h.avatar), o.push(n);
                }
                a(o);
            }
        });
    }
    static ot(t, s) {
        var e = this.nt(t, s.ht());
        e ? (e.ut() || e.dt(s.ut()), e.lt() || e.ct(s.lt()), e.pt() || e.vt(s.pt()), e.ft() || e.gt(s.ft()), 
        e.Ut() && "" != e.Ut() || e.At(s.Ut())) : t.push(s);
    }
    static wt(t, s) {
        var e;
        (e = t.findIndex(t => t.ht() == s.ht())) >= 0 ? t[e] = s : t.push(s);
    }
    Mt(t) {
        var s = {}, e = t.media;
        for (let i = 0; i < e.length; i++) {
            const r = e[i];
            (s = new Object).storyId = t.id, s.id = r.id, s.canViewMedia = r.canView, s.thumb = r.files.thumb.url, 
            s.preview = r.files.preview.url, s.postedAt = t.createdAt, s.url = r.files.source.url, 
            s.type = r.type, s.hasMedia = true, s.duration = r.files.source.duration || 0, this.N.push(s);
        }
    }
    yt(t) {
        var s;
        t.mediaCount <= 0 || t.media.forEach(e => {
            new Object, s = {
                id: e.id,
                dmId: t.id,
                type: e.type,
                canViewMedia: e.canView,
                preview: e.preview,
                url: e.source.source,
                thumb: e.thumb,
                postedAt: t.createdAt,
                postedAtPrecise: void 0,
                rawText: t.text,
                text: t.text,
                hasMedia: true,
                duration: e.duration || 0
            };
            var i;
            (i = this.J.findIndex(t => t.id == e.id)) >= 0 ? this.J[i] = s : this.J.push(s);
        });
    }
    kt(t) {
        try {
            var s = t.split("?");
            return s.length >= 1 ? s[0] : t;
        } catch (s) {
            return t;
        }
    }
    Pt(t) {
        this.O = this.O.filter(s => s.postId != t);
    }
    bt(s) {
        var e;
        s.media.forEach(i => {
            e = new Object, e = {
                id: i.id,
                postId: s.id,
                type: i.type,
                canViewMedia: i.canView,
                preview: i.preview,
                url: i.source.source,
                thumb: i.thumb,
                postedAt: s.postedAt,
                postedAtPrecise: s.postedAtPrecise,
                rawText: s.rawText,
                text: s.text,
                hasMedia: true,
                postMediaCount: s.mediaCount,
                duration: i.info.source.duration || 0
            }, i.canView || (e.url = "", e.preview = "", e.thumb = ""), e.thumb || (e.thumb = ""), 
            "gif" == e.type && (e.type = "video");
            var r;
            (r = this.O.findIndex(e => e.postId == s.id && t.p(e.url) == t.p(i.source.source))) >= 0 ? this.O[r] = e : this.O.push(e);
        }), s.media.length <= 0 && (e = {
            id: void 0,
            postId: s.id,
            type: "N/A",
            canViewMedia: s.canViewMedia,
            preview: "",
            url: "",
            thumb: "",
            postedAt: s.postedAt,
            postedAtPrecise: s.postedAtPrecise,
            rawText: s.rawText,
            text: s.text,
            hasMedia: false,
            postMediaCount: 0
        }, this.O.push(e));
    }
    Ct(t) {
        return this.O.filter(s => s.postId == t);
    }
    static nt(t, s) {
        return t.find(t => t.ht() == s);
    }
    It() {
        var s = this.A + "users/" + this.P + "?app-token=" + this.st, e = t.s(s, this.tt, this.Z), i = t.t(s, e);
        return i.then(t => {
            t && 200 == t.status && t.json && (t.json.isPerformer && (t.json.avatarThumbs && t.json.avatarThumbs.c50 && this.it(t.json.avatarThumbs.c50), 
            t.json.avatarThumbs && t.json.avatarThumbs.c144 && this.rt(t.json.avatarThumbs.c144), 
            t.json.avatar && this.at(t.json.avatar)), this.Tt(t.json.photosCount), this.St(t.json.videosCount), 
            this._t(t.json.audiosCount), this.$t(t.json.postsCount), this.xt(t.json.joinDate), 
            this.Dt(t.json.archivedPostsCount), this.Ft(t.json.hasStories || false));
        }), i;
    }
    static Lt(t, s) {
        return t.find(t => t.ft() == s);
    }
    Ot() {
        return JSON.stringify(this);
    }
    xt(t) {
        var s = t.split("T");
        this.K = s[0];
    }
    Jt() {
        return this.K;
    }
    Nt(t) {
        this.q = t;
    }
    Rt() {
        return this.q;
    }
    ct(t) {
        this.Z = t;
    }
    lt() {
        return this.Z;
    }
    vt(t) {
        this.tt = t;
    }
    pt() {
        return this.tt;
    }
    dt(t) {
        this.st = t;
    }
    ut() {
        return this.st;
    }
    it(t) {
        this.H = t;
    }
    Vt() {
        return this.H;
    }
    rt(t) {
        this.W = t;
    }
    jt() {
        return this.W;
    }
    at(t) {
        this.Y = t;
    }
    Bt() {
        return this.Y;
    }
    Et() {
        return this.O;
    }
    Ht() {
        return this.J;
    }
    Wt() {
        return this.N;
    }
    Yt() {
        var t = {
            photo: 0,
            video: 0
        };
        return this.O.forEach(s => {
            "photo" == s.type ? t.photo++ : t.video++;
        }), t;
    }
    Tt(t) {
        this.R = t;
    }
    qt() {
        return this.R;
    }
    St(t) {
        this.V = t;
    }
    zt() {
        return this.V + this.j;
    }
    _t(t) {
        this.j = t;
    }
    Gt() {
        return this.j;
    }
    $t(t) {
        this.B = t;
    }
    Kt() {
        return this.B;
    }
    Qt() {
        return this.X;
    }
    Dt(t) {
        this.X = t;
    }
    Xt() {
        return this.G;
    }
    Zt() {
        return this.G ? "Yes" : "No";
    }
    Ft(t) {
        this.G = t;
    }
    ht() {
        return this.M;
    }
    gt(t) {
        this.P = t;
    }
    ft() {
        return this.P;
    }
    At(t) {
        this._ = t;
    }
    Ut() {
        return this._;
    }
    ts(t) {
        var s;
        return (s = this.O.findIndex(s => s.id && s.id == t)) >= 0 ? this.O[s] : void 0;
    }
    ss(t) {
        var s;
        return (s = this.J.findIndex(s => s.id && s.id == t)) >= 0 ? this.J[s] : void 0;
    }
    es(t) {
        var s;
        return (s = this.N.findIndex(s => s.id && s.id == t)) >= 0 ? this.N[s] : void 0;
    }
    static rs(t) {
        var e = new s, i = JSON.parse(t);
        return Object.assign(e, i), e;
    }
    static as(t, e, i, r) {
        s.os(0, {
            userIdArray: [],
            mediaHash: {}
        }, t, e, i, (function(a, o, n) {
            var h = a.userIdArray;
            if (o) {
                if (0 == h.length) return void r(o, n, []);
                var u = false, d = [];
                for (const t in a.mediaHash) {
                    let s = a.mediaHash[t];
                    for (let t = 0; t < s.length; t++) {
                        const e = s[t];
                        var l = e.purchasedFrom;
                        if (!(l && l.username && l.name)) {
                            u = true;
                            break;
                        }
                        d.push(e);
                    }
                }
                if (!u) return void r(o, n, d);
                s.ns(h, t, e, i, (function(t, e, i) {
                    var o = s.hs(h, i, a.mediaHash);
                    r(t, e, o);
                }));
            } else r(o, n, []);
        }));
    }
    static hs(t, s, e) {
        var i = [];
        for (let o = 0; o < t.length; o++) {
            const n = t[o];
            var r = e[n], a = s[n];
            for (let t = 0; t < r.length; t++) {
                const s = r[t];
                s.purchasedFrom = {
                    userId: n,
                    username: a.username,
                    name: a.name
                }, i.push(s);
            }
        }
        return i;
    }
    static os(e, i, r, a, o, n) {
        var h = true, u = "";
        var d = new URL(`https://onlyfans.com/api2/v2/posts/paid?limit=100&offset=${e}&skip_users_dups=1&app-token=${r}`), l = t.s(d.href, o, a);
        t.t(d.href, l).then(t => {
            var d, l, c = t.json;
            if (t.ok && c && Array.isArray(c)) {
                for (let t = 0; t < c.length; t++) {
                    const s = c[t];
                    d = "", l = s.media;
                    for (let t = 0; t < l.length; t++) {
                        const e = l[t];
                        var p = s.author || s.fromUser;
                        e.duration = e.info.source.duration || e.duration || 0, e.purchasedFrom = p, "post" == s.responseType ? (e.postedAt = s.postedAt, 
                        e.rawText = s.rawText) : "message" == s.responseType && (e.postedAt = s.createdAt, 
                        e.rawText = s.text), "gif" == e.type && (e.type = "video"), e.price = s.price;
                    }
                    "post" == s.responseType ? (d = s.author.id, i.userIdArray.push(d)) : "message" == s.responseType && (d = s.fromUser.id, 
                    i.userIdArray.push(d)), i.mediaHash[d] ? i.mediaHash[d] = i.mediaHash[d].concat(l) : i.mediaHash[d] = l;
                }
                c.length >= 100 ? (e += 100, s.os(e, i, r, a, o, n)) : (i.userIdArray = Array.from(new Set(i.userIdArray)), 
                n(i, h, u));
            }
        }).catch(t => {
            n(h = false, u = t);
        });
    }
    static ns(s, e, i, r, a) {
        var o = [];
        for (let a = 0; a < s.length; a++) {
            const d = s[a];
            var n = new URL(`https://onlyfans.com/api2/v2/users/${d}?app-token=${e}`), h = t.s(n.href, r, i), u = t.t(n.href, h);
            o.push(u);
        }
        Promise.all(o).then(t => {
            var s = {};
            for (let r = 0; r < t.length; r++) {
                const a = t[r];
                var e = a.json;
                if (a.ok && e) {
                    var i = e.id;
                    s[i] = {}, s[i].username = e.username, s[i].name = e.name;
                }
            }
            a(true, "", s);
        });
    }
    us(s, e, i, r) {
        this.O = [];
        var a = t.S(e + "T23:59:00"), o = t.S(s + "T00:00:00");
        this.ds(o, a, i, r);
    }
    ds(s, e, i, r) {
        var a, o = true, n = "", h = this.M;
        a = i ? `users/${h}/posts/archived?limit&order=publish_date_desc&skip_users=all&skip_users_dups=1&beforePublishTime=&app-token=` : `users/${h}/posts?limit&order=publish_date_desc&skip_users=all&skip_users_dups=1&beforePublishTime=&app-token=`;
        var u = new URL(this.A + a);
        u.searchParams.set("beforePublishTime", "" + e), u.searchParams.set("app-token", "" + this.st), 
        u.searchParams.set("limit", "100");
        var d = t.s(u.href, this.tt, this.Z), l = t.t(u.href, d);
        return l.then(t => {
            var a = 0, h = t.json;
            if (t.ok && h && Array.isArray(h)) {
                var u;
                for (let t = 0; t < h.length; t++) {
                    const e = h[t];
                    (u = e.postedAtPrecise) >= s && (this.bt(e), a++);
                }
                u >= s && a >= 100 ? (e = u, this.ds(s, e, i, r)) : r instanceof Function && r(o, n);
            } else t.ok || (o = false, n = t.json, r(o, n));
        }).catch(t => {
            r(o = false, n = t);
        }), l;
    }
    ls(s) {
        this.N = [];
        var e = new URL(`https://onlyfans.com/api2/v2/users/${this.M}/stories?unf=1&app-token=${this.st}`), i = t.s(e.href, this.tt, this.Z);
        t.t(e.href, i).then(t => {
            var e = t.json;
            if (t.ok && e && Array.isArray(e) && e.length > 0) for (let t = 0; t < e.length; t++) {
                const s = e[t];
                this.Mt(s);
            }
            s instanceof Function && s(true, "");
        }).catch(t => {
            s instanceof Function && s(false, t);
        });
    }
    cs(s, e, i) {
        this.J = [];
        var r = t.S(e + "T23:59:00"), a = t.S(s + "T00:00:00");
        this.ps(a, r, 0, i);
    }
    ps(s, e, i, r) {
        var a = true, o = "", n = `chats/${this.M}/media?order=desc&limit=10&offset=${i}&filter=all&app-token=${this.st}`, h = new URL(this.A + n), u = t.s(h.href, this.tt, this.Z), d = t.t(h.href, u);
        return d.then(n => {
            var h = n.json;
            if (n.ok && h && h.list && Array.isArray(h.list)) {
                var u;
                for (let i = 0; i < h.list.length; i++) {
                    const r = h.list[i];
                    (u = t.S(r.createdAt)) >= s && u <= e && this.yt(r);
                }
                h.hasMore && u >= s && u <= e ? (i = i + h.list.length - 1, this.ps(s, e, i, r)) : r instanceof Function && r(a, o);
            } else n.ok || (a = false, o = n.json, r(a, o));
        }).catch(t => {
            r(a = false, o = t);
        }), d;
    }
}