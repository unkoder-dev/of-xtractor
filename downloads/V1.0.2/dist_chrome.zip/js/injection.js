!function() {
    var t = XMLHttpRequest.prototype, s = t.send, n = t.open;
    t.open = function(t, s) {
        return this.url = s, n.apply(this, arguments);
    };
    var i = window.XMLHttpRequest.prototype.open;
    window.XMLHttpRequest.prototype.open = function() {
        var t = [].slice.call(arguments);
        return i.apply(this, t);
    }, t.send = function() {
        return this.addEventListener("load", (function() {
            var t = this.url;
            if (t.includes("onlyfans.com/api2/v2/") && (t.includes("posts") || t.includes("/v2/users/") || t.includes("/v2/chats") || t.includes("/v2/messages")) && !t.includes("stats-collect") && !t.includes("highlights")) {
                this.getAllResponseHeaders();
                var s = JSON.parse(this.response);
                const n = new CustomEvent("__HTTPRESPONSE__", {
                    detail: {
                        status: this.status,
                        url: t,
                        response: s
                    }
                });
                document.body.dispatchEvent(n);
            }
        })), s.apply(this, arguments);
    };
}();