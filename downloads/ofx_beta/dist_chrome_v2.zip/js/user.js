class s {
    constructor(t, s, e, i, r, a) {
        this.A = "https://onlyfans.com/api2/v2/", this.M = t, this.P = s, this.C = e, this._ = [], 
        this.O = [], this.J = [], this.R = [], this.V = 0, this.B = 0, this.H = 0, this.W = 0, 
        this.Y, this.q, this.G, this.K = false, this.X = false, this.Z = "1970-01-01", this.tt = 0, 
        this.st = i, this.et = r, this.it = a;
    }
    static rt(e, i, r, a) {
        if (!e || !i || !r) throw "Session cookie, user agent and appToken needed";
        var o = new URL("https://onlyfans.com/api2/v2/subscriptions/subscribes?offset=0&type=active&limit=1000");
        o.searchParams.set("app-token", r);
        var n = t.s(o.href, i, e);
        t.t(o.href, n, (function() {})).then(t => {
            if (a instanceof Function) {
                if (!(t.ok && t.json && Array.isArray(t.json))) throw t;
                var o = [];
                for (let a = 0; a < t.json.length; a++) {
                    const h = t.json[a];
                    var n = new s(h.id, h.username, h.name, e, i, r);
                    h.avatarThumbs && h.avatarThumbs.c50 && n.at(h.avatarThumbs.c50), h.avatarThumbs && h.avatarThumbs.c144 && n.ot(h.avatarThumbs.c144), 
                    h.avatar && n.nt(h.avatar), o.push(n);
                }
                a(o);
            }
        });
    }
    static ht(t, s) {
        var e = this.ut(t, s.lt());
        e ? (e.dt() || e.ct(s.dt()), e.vt() || e.pt(s.vt()), e.ft() || e.Ut(s.ft()), e.gt() || e.At(s.gt()), 
        e.yt() && "" != e.yt() || e.wt(s.yt())) : t.push(s);
    }
    static Mt(t, s) {
        var e;
        (e = t.findIndex(t => t.lt() == s.lt())) >= 0 ? t[e] = s : t.push(s);
    }
    kt(s) {
        var e = {}, i = s.media;
        for (let r = 0; r < i.length; r++) {
            const a = i[r];
            (e = new Object).storyId = s.id, e.id = a.id, e.canViewMedia = a.canView, e.thumb = a.files && a.files.thumb && a.files.thumb.url || void 0, 
            e.preview = a.files && a.files.preview && a.files.preview.url || void 0, e.postedAt = s.createdAt;
            try {
                e.postedAtPrecise = t.N(e.postedAt);
            } catch (t) {
                e.postedAtPrecise = void 0;
            }
            e.url = a.files && a.files.source && a.files.source.url || "", e.type = a.type, 
            e.hasMedia = true, e.duration = a.files && a.files.source && a.files.source.duration || 0, 
            this.R.push(e);
        }
    }
    Pt(s) {
        var e;
        s.mediaCount <= 0 || s.media.forEach(i => {
            e = new Object, e = {
                id: i.id,
                dmId: s.id,
                type: i.type,
                canViewMedia: i.canView,
                preview: i.preview,
                url: i.source.source,
                thumb: i.thumb,
                postedAt: s.createdAt,
                postedAtPrecise: void 0,
                rawText: s.text,
                text: s.text,
                hasMedia: true,
                duration: i.duration || 0
            };
            try {
                e.postedAtPrecise = t.N(e.postedAt);
            } catch (t) {
                e.postedAtPrecise = void 0;
            }
            var r;
            (r = this.J.findIndex(t => t.id == i.id)) >= 0 ? this.J[r] = e : this.J.push(e);
        });
    }
    bt(t) {
        try {
            var s = t.split("?");
            return s.length >= 1 ? s[0] : t;
        } catch (s) {
            return t;
        }
    }
    Ct(t) {
        this.O = this.O.filter(s => s.postId != t);
    }
    It(s) {
        var e;
        for (let a = 0; a < s.media.length; a++) {
            var i = s.media[a];
            e = new Object;
            try {
                if (!(e = {
                    id: i.id,
                    postId: s.id,
                    type: i.type,
                    canViewMedia: i.canView,
                    preview: i.preview,
                    url: i.source && i.source.source || i.files && i.files.full || i.files && i.files.preview && i.files.preview.url || i.preview || void 0,
                    thumb: i.thumb,
                    postedAt: s.postedAt,
                    postedAtPrecise: s.postedAtPrecise,
                    rawText: s.rawText,
                    text: s.text,
                    hasMedia: true,
                    postMediaCount: s.mediaCount,
                    duration: i.info && i.info.source && i.info.source.duration || 0
                }).url) continue;
                i.canView || (e.url = "", e.preview = "", e.thumb = ""), e.thumb || (e.thumb = e.url), 
                "gif" == e.type && (e.type = "video");
                var r;
                (r = this.O.findIndex(i => i.postId == s.id && t.p(i.url) == t.p(e.url))) >= 0 ? this.O[r] = e : this.O.push(e);
            } catch (t) {}
        }
        s.media.length <= 0 && (e = {
            id: void 0,
            postId: s.id,
            type: "N/A",
            canViewMedia: s.canViewMedia,
            preview: "",
            url: "",
            thumb: "",
            postedAt: s.postedAt,
            postedAtPrecise: s.postedAtPrecise,
            rawText: s.rawText,
            text: s.text,
            hasMedia: false,
            postMediaCount: 0
        }, this.O.push(e));
    }
    Tt(t) {
        return this.O.filter(s => s.postId == t);
    }
    static ut(t, s) {
        return t.find(t => t.lt() == s);
    }
    St() {
        var s = this.A + "users/" + this.P + "?app-token=" + this.it, e = t.s(s, this.et, this.st), i = t.t(s, e);
        return i.then(t => {
            t && 200 == t.status && t.json && (t.json.isPerformer && (t.json.avatarThumbs && t.json.avatarThumbs.c50 && this.at(t.json.avatarThumbs.c50), 
            t.json.avatarThumbs && t.json.avatarThumbs.c144 && this.ot(t.json.avatarThumbs.c144), 
            t.json.avatar && this.nt(t.json.avatar)), t.json.photosCount && this._t(t.json.photosCount), 
            t.json.videosCount && this.$t(t.json.videosCount), t.json.audiosCount && this.xt(t.json.audiosCount), 
            t.json.postsCount && this.Dt(t.json.postsCount), t.json.joinDate && this.Ft(t.json.joinDate), 
            t.json.archivedPostsCount && this.Lt(t.json.archivedPostsCount), t.json.hasStories && this.Ot(t.json.hasStories || false));
        }), i;
    }
    static Jt(t, s) {
        return t.find(t => t.gt() == s);
    }
    Nt() {
        return JSON.stringify(this);
    }
    Ft(t) {
        try {
            var s = t.split("T");
            this.Z = s[0];
        } catch (t) {
            this.Z = "1970-01-01";
        }
    }
    Rt() {
        return this.Z;
    }
    Vt(t) {
        this.K = t;
    }
    jt() {
        return this.K;
    }
    pt(t) {
        this.st = t;
    }
    vt() {
        return this.st;
    }
    Ut(t) {
        this.et = t;
    }
    ft() {
        return this.et;
    }
    ct(t) {
        this.it = t;
    }
    dt() {
        return this.it;
    }
    at(t) {
        this.Y = t;
    }
    Bt() {
        return this.Y;
    }
    ot(t) {
        this.q = t;
    }
    Et() {
        return this.q;
    }
    nt(t) {
        this.G = t;
    }
    Ht() {
        return this.G;
    }
    Wt() {
        return this.O;
    }
    Yt() {
        return this.J;
    }
    qt() {
        return this.R;
    }
    zt() {
        var t = {
            photo: 0,
            video: 0
        };
        return this.O.forEach(s => {
            "photo" == s.type ? t.photo++ : t.video++;
        }), t;
    }
    _t(t) {
        this.V = t;
    }
    Gt() {
        return this.V;
    }
    $t(t) {
        this.B = t;
    }
    Kt() {
        return this.B + this.H;
    }
    xt(t) {
        this.H = t;
    }
    Qt() {
        return this.H;
    }
    Dt(t) {
        this.W = t;
    }
    Xt() {
        return this.W;
    }
    Zt() {
        return this.tt;
    }
    Lt(t) {
        this.tt = t;
    }
    ts() {
        return this.X;
    }
    ss() {
        return this.X ? "Yes" : "No";
    }
    Ot(t) {
        this.X = t;
    }
    lt() {
        return this.M;
    }
    At(t) {
        this.P = t;
    }
    gt() {
        return this.P;
    }
    wt(t) {
        this.C = t;
    }
    yt() {
        return this.C;
    }
    es(t) {
        var s;
        return (s = this.O.findIndex(s => s.id && s.id == t)) >= 0 ? this.O[s] : void 0;
    }
    rs(t) {
        var s;
        return (s = this.J.findIndex(s => s.id && s.id == t)) >= 0 ? this.J[s] : void 0;
    }
    as(t) {
        var s;
        return (s = this.R.findIndex(s => s.id && s.id == t)) >= 0 ? this.R[s] : void 0;
    }
    static os(t) {
        var e = new s, i = JSON.parse(t);
        return Object.assign(e, i), e;
    }
    static ns(t, e, i, r) {
        s.hs(0, {
            userIdArray: [],
            mediaHash: {}
        }, t, e, i, (function(a, o, n) {
            var h = a.userIdArray;
            if (o) {
                if (0 == h.length) return void r(o, n, []);
                var u = false, l = [];
                for (const t in a.mediaHash) {
                    let s = a.mediaHash[t];
                    for (let t = 0; t < s.length; t++) {
                        const e = s[t];
                        var d = e.purchasedFrom;
                        if (!(d && d.username && d.name)) {
                            u = true;
                            break;
                        }
                        l.push(e);
                    }
                }
                if (!u) return void r(o, n, l);
                s.us(h, t, e, i, (function(t, e, i) {
                    var o = s.ls(h, i, a.mediaHash);
                    r(t, e, o);
                }));
            } else r(o, n, []);
        }));
    }
    static ls(t, s, e) {
        var i = [];
        for (let o = 0; o < t.length; o++) {
            const n = t[o];
            var r = e[n], a = s[n];
            for (let t = 0; t < r.length; t++) {
                const s = r[t];
                s.purchasedFrom = {
                    userId: n,
                    username: a.username,
                    name: a.name
                }, i.push(s);
            }
        }
        return i;
    }
    static hs(e, i, r, a, o, n) {
        var h = true, u = "";
        var l = new URL(`https://onlyfans.com/api2/v2/posts/paid?limit=100&offset=${e}&skip_users_dups=1&app-token=${r}`), d = t.s(l.href, o, a);
        t.t(l.href, d).then(l => {
            var d, c, v = l.json;
            if (l.ok && v && Array.isArray(v)) {
                for (let s = 0; s < v.length; s++) {
                    const e = v[s];
                    d = "", c = e.media;
                    for (let s = 0; s < c.length; s++) {
                        const i = c[s];
                        var p = e.author || e.fromUser;
                        i.duration = i.info.source.duration || i.duration || 0, i.purchasedFrom = p, "post" == e.responseType ? (i.postedAt = e.postedAt, 
                        i.postedAtPrecise = e.postedAtPrecise, i.rawText = e.rawText) : "message" == e.responseType && (i.postedAt = e.createdAt, 
                        i.postedAtPrecise = t.N(i.postedAt), i.rawText = e.text), "gif" == i.type && (i.type = "video"), 
                        i.price = e.price;
                    }
                    "post" == e.responseType ? (d = e.author.id, i.userIdArray.push(d)) : "message" == e.responseType && (d = e.fromUser.id, 
                    i.userIdArray.push(d)), i.mediaHash[d] ? i.mediaHash[d] = i.mediaHash[d].concat(c) : i.mediaHash[d] = c;
                }
                v.length >= 100 ? (e += 100, s.hs(e, i, r, a, o, n)) : (i.userIdArray = Array.from(new Set(i.userIdArray)), 
                n(i, h, u));
            }
        }).catch(t => {
            n(h = false, u = t);
        });
    }
    static us(s, e, i, r, a) {
        var o = true, n = "", h = [], u = {};
        for (let a = 0; a < s.length; a++) {
            const o = s[a];
            var l = new URL(`https://onlyfans.com/api2/v2/users/${o}?app-token=${e}`), d = t.s(l.href, r, i), c = t.t(l.href, d);
            h.push(c), c.then(t => {
                false == t.ok && (u[o] = {}, u[o] = t.json);
            });
        }
        Promise.all(h).then(t => {
            for (let i = 0; i < t.length; i++) {
                const r = t[i];
                var s = r.json;
                if (r.ok && true == r.ok && s) {
                    var e = s.id;
                    u[e] = {}, u[e] = s;
                }
            }
            a(o, n, u);
        }).catch(t => {
            a(o = false, n = t, u = {});
        });
    }
    ds(s, e, i, r) {
        this.O = [];
        var a = t.j(e + "T23:59:00"), o = t.j(s + "T00:00:00");
        this.cs(o, a, i, r);
    }
    cs(s, e, i, r) {
        var a, o = true, n = "", h = this.M;
        a = i ? `users/${h}/posts/archived?limit&order=publish_date_desc&skip_users=all&skip_users_dups=1&beforePublishTime=&app-token=` : `users/${h}/posts?limit&order=publish_date_desc&skip_users=all&skip_users_dups=1&beforePublishTime=&app-token=`;
        var u = new URL(this.A + a);
        u.searchParams.set("beforePublishTime", "" + e), u.searchParams.set("app-token", "" + this.it), 
        u.searchParams.set("limit", "100");
        var l = t.s(u.href, this.et, this.st), d = t.t(u.href, l);
        return d.then(t => {
            var a = 0, h = t.json;
            if (t.ok && h && Array.isArray(h)) {
                var u;
                for (let t = 0; t < h.length; t++) {
                    const e = h[t];
                    (u = e.postedAtPrecise) >= s && (this.It(e), a++);
                }
                u >= s && a >= 100 ? (e = u, this.cs(s, e, i, r)) : r instanceof Function && r(o, n);
            } else t.ok || (o = false, n = t.json, r(o, n));
        }).catch(t => {
            r(o = false, n = t);
        }), d;
    }
    vs(s) {
        this.R = [];
        var e = new URL(`https://onlyfans.com/api2/v2/users/${this.M}/stories?unf=1&app-token=${this.it}`), i = t.s(e.href, this.et, this.st);
        t.t(e.href, i).then(t => {
            var e = t.json;
            if (t.ok && e && Array.isArray(e) && e.length > 0) for (let t = 0; t < e.length; t++) {
                const s = e[t];
                this.kt(s);
            }
            s instanceof Function && s(true, "");
        }).catch(t => {
            s instanceof Function && s(false, t);
        });
    }
    ps(s, e, i) {
        this.J = [];
        var r = t.j(e + "T23:59:00"), a = t.j(s + "T00:00:00");
        this.fs(a, r, 0, i);
    }
    fs(s, e, i, r) {
        var a = true, o = "", n = `chats/${this.M}/media?order=desc&limit=10&offset=${i}&filter=all&app-token=${this.it}`, h = new URL(this.A + n), u = t.s(h.href, this.et, this.st), l = t.t(h.href, u);
        return l.then(n => {
            var h = n.json;
            if (n.ok && h && h.list && Array.isArray(h.list)) {
                var u;
                for (let i = 0; i < h.list.length; i++) {
                    const r = h.list[i];
                    (u = t.j(r.createdAt)) >= s && u <= e && this.Pt(r);
                }
                h.hasMore && u >= s && u <= e ? (i = i + h.list.length - 1, this.fs(s, e, i, r)) : r instanceof Function && r(a, o);
            } else n.ok || (a = false, o = n.json, r(a, o));
        }).catch(t => {
            r(a = false, o = t);
        }), l;
    }
}