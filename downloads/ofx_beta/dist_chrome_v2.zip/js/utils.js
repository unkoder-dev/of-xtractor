class t {
    constructor() {}
    static t(t, e, a) {
        var r = fetch(t, {
            headers: e
        }).then(t => t.json().then(e => ({
            ok: t.ok,
            status: t.status,
            url: t.url,
            headers: t.headers,
            json: e
        }))).catch(e => ({
            ok: false,
            status: 404,
            url: t,
            headers: [],
            json: {}
        }));
        return a instanceof Function && r.then(t => {
            a(t);
        }), r;
    }
    static i(t, e, a) {
        navigator.permissions.query({
            name: "clipboard-write"
        }).then(t => {
            if ("granted" === t.state) {
                var e = new Blob([ "hello" ], {
                    type: "text/plain"
                }), r = new ClipboardItem({
                    "text/plain": e
                });
                navigator.clipboard.write([ r ]).then((function() {
                    a("");
                }), (function(t) {
                    a("unable to write to clipboard. Error:", t);
                }));
            } else a("clipboard-permissoin not granted: " + t);
        });
    }
    static o(t, e, a) {
        var r = "";
        for (let e = 0; e < t.length; e++) {
            r = r + t[e] + "\n";
        }
        e.writeText(r).then(() => {
            a("");
        }).catch(t => {
            a(t);
        });
    }
    static s(e, a, r) {
        var n = Date.now(), i = r + "\n" + n + "\n" + t.u(e) + "\n" + a + "\nonlyfans";
        return {
            sign: this.l(i),
            time: n,
            accept: "application/json, text/plain, */*",
            "access-token": r
        };
    }
    static p(t) {
        try {
            return t.split("/").pop().split("?")[0];
        } catch (t) {
            return "";
        }
    }
    static u(t) {
        return t = t.replace(/^.*\/\/[^\/]+/, "");
    }
    static v(t, e, a, r) {
        var n, i, o, s;
        s = this.m(t.getDate(), 10), n = this.m(t.getHours(), 10), i = this.m(t.getMinutes(), 10), 
        o = this.m(t.getSeconds(), 10);
        var c = a && `${n}:${i}` || "";
        c = c + (a && r && ":" + o) || "";
        var u = e && t.getFullYear() || "";
        return `${[ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec" ][t.getMonth()]} ${s}, ${u} ${c}`;
    }
    static m(t, e) {
        return t < e ? "0" + t : t;
    }
    static g() {
        var t = new Date, e = "" + (t.getMonth() + 1), a = "" + t.getDate(), r = t.getFullYear();
        return e.length < 2 && (e = "0" + e), a.length < 2 && (a = "0" + a), [ r, e, a ].join("-");
    }
    static D(t) {
        1 == t.split("T").length && (t += "T00:00:00");
        var e = new Date(t), a = e.getMonth() + 1;
        a < 10 && (a = "0" + a);
        e.getDate();
        return e.getFullYear() + "-" + a + "-" + e.getDate();
    }
    static h(t) {
        1 == t.split("T").length && (t += "T00:00:00");
        var e = new Date(t), a = e.getMonth() + 1;
        a < 10 && (a = "0" + a);
        var r = e.getDate();
        return r < 10 && (r = "0" + r), e.getFullYear() + "-" + a + "-" + e.getDate();
    }
    static T(t) {
        t instanceof Date || 1 == t.split("T").length && (t += "T00:00:00");
        var e = new Date(t), a = e.getMonth() + 1;
        a < 10 && (a = "0" + a);
        var r = e.getDate();
        r < 10 && (r = "0" + r);
        var n = e.getHours();
        n < 10 && (n = "0" + n);
        var i = e.getMinutes();
        i < 10 && (i = "0" + i);
        var o = e.getSeconds();
        return o < 10 && (o = "0" + o), e.getFullYear() + "-" + a + "-" + r + "T" + n + ":" + i + ":" + o;
    }
    static F(t, e) {
        t = this.T(t), e.includes("es") || e.includes("en") || (e = "en-US"), e = "es-CH";
        try {
            var a = new Date(t);
            return a.toLocaleDateString(e, {
                month: "2-digit",
                day: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit"
            });
        } catch (t) {
            return "";
        }
    }
    static L(t, e) {
        var a = t.createElement("BUTTON");
        a.setAttribute("class", "ofx-regular-button");
        var r = t.createElement("p"), n = t.createTextNode(e);
        return r.appendChild(n), a.appendChild(r), a;
    }
    static S(t) {
        var e = document.createElement("label");
        e.setAttribute("class", "g-input__label"), e.setAttribute("class", "g-input__label");
        var a = document.createTextNode(t);
        return e.appendChild(a), e;
    }
    static $(t, e) {
        const a = document.createElement("option");
        a.disabled = true;
        const r = document.createTextNode(t);
        return a.appendChild(r), a.setAttribute("value", e), a;
    }
    static k(t) {
        var e = document.createElement("input");
        return e.setAttribute("type", "date"), e.setAttribute("class", "g-input form-control"), 
        e.setAttribute("id", t), e;
    }
    static I(t) {
        var e = new Date(t), a = "" + (e.getMonth() + 1), r = "" + e.getDate(), n = e.getFullYear();
        return a.length < 2 && (a = "0" + a), r.length < 2 && (r = "0" + r), [ n, a, r ].join("-");
    }
    static N(t) {
        try {
            return new Date(t).getTime() / 1000 + ".000000";
        } catch (t) {
            return "";
        }
    }
    static U(t) {
        return new Date(1000 * t);
    }
    static j(t) {
        return new Date(t).getTime() / 1000 + ".000000";
    }
    static l(t) {
        var e, a, r, n, i, o = [], s = [ a = 0x67452301, r = 0xefcdab89, ~a, ~r, 0xc3d2e1f0 ], c = [], u = unescape(encodeURI(t)) + "", l = u.length;
        for (c[t = --l / 4 + 2 | 15] = 8 * l; ~l; ) c[l >> 2] |= u.charCodeAt(l) << 8 * ~l--;
        for (e = l = 0; e < t; e += 16) {
            for (a = s; l < 80; a = [ a[4] + (o[l] = l < 16 ? ~~c[e + l] : 2 * u | u < 0) + 1518500249 + [ r & n | ~r & i, u = 341275144 + (r ^ n ^ i), 882459459 + (r & n | r & i | n & i), u + 1535694389 ][l++ / 5 >> 2] + ((u = a[0]) << 5 | u >>> 27), u, r << 30 | r >>> 2, n, i ]) u = o[l - 3] ^ o[l - 8] ^ o[l - 14] ^ o[l - 16], 
            r = a[1], n = a[2], i = a[3];
            for (l = 5; l; ) s[--l] += a[l];
        }
        for (u = ""; l < 40; ) u += (s[l >> 3] >> 4 * (7 - l++) & 15).toString(16);
        return u;
    }
}