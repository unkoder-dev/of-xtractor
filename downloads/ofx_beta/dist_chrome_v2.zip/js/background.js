function ee() {
    if ("undefined" != typeof chrome) return "undefined" != typeof browser ? browser : chrome;
}

var re = ee();

function te(e, r, t) {
    var o = {
        from: "background"
    };
    o.to = t, o.subject = e, o.payload = r, chrome.tabs.query({
        url: "*://*.onlyfans.com/*"
    }, (function(e) {
        for (let r of e) chrome.tabs.sendMessage(r.id, o, (function(e) {}));
    }));
}

function oe(e) {
    if (!(e.length <= 0)) {
        var r = e[0];
        e.shift(), ne(r), e.length > 0 && setTimeout(() => {
            oe(e);
        }, 400);
    }
}

function ne(e) {
    chrome.storage.sync.get({
        re: true
    }, (function(r) {
        if (r.re) {
            var t = e.path + e.filename;
            chrome.downloads.download({
                url: e.url,
                filename: t,
                conflictAction: "uniquify",
                saveAs: false
            });
        } else chrome.downloads.download({
            url: e.url,
            conflictAction: "uniquify",
            saveAs: false
        });
    }));
}

function ie(e) {
    if (!(e.length <= 0)) {
        var r = e[0];
        e.shift(), ae(chrome.downloads, r.url, r.folder, r.type, r.filename);
        e.length > 0 && setTimeout((function() {
            ie(e);
        }), 400);
    }
}

function ae(e, r, t, o, n) {
    chrome.storage.sync.get({
        re: true
    }, (function(i) {
        if (i.re) {
            var a = t + "/" + o + "/" + n;
            e.download({
                url: r,
                filename: a,
                conflictAction: "uniquify",
                saveAs: false
            });
        } else e.download({
            url: r,
            conflictAction: "uniquify",
            saveAs: false
        });
    }));
}

function ce(e) {
    for (let r = 0; r < Ue.length; r++) {
        Ue[r].gt() == e && Ue.splice(r, 1);
    }
}

function se(e, r, t) {
    try {
        var o = new s(e, r, t, $e, ke, xt);
        o.St(), s.ht(Ue, o);
    } catch (e) {}
}

function fe(e) {
    var r = [];
    for (let o = 0; o < e.length; o++) {
        const n = e[o];
        var t;
        try {
            (t = s.os(n)).jt() || s.Mt(r, t);
        } catch (e) {}
    }
    Ue = r, De = true;
}

function kt(e, r, t) {
    if ("getUserList" == e.subject) {
        var o = Ae();
        t([ De, o ]);
    } else if ("setUserList" == e.subject) t(), fe(e.payload[0]); else if ("downloadFiles" == e.subject) t(), 
    oe(e.payload[0]); else if ("getSessionParams" == e.subject) je(0, (function(e, r, o) {
        var n = {};
        n.sescookie = $e, n.useragent = navigator.userAgent, n.appToken = xt, n.imLoggedIn = Xt, 
        n.alertsCount = Ne, chrome.storage.sync.get({
            dateBeforeFilename: false,
            chatsSeparateFolder: false,
            storiesSeparateFolder: false
        }, (function(e) {
            n.settings = e, t([ n ]);
        }));
    })); else if ("setSettings" == e.subject) {
        var n = e.payload[0];
        chrome.storage.sync.set(n, (function() {
            t(true);
        }));
    } else {
        if ("addUserToMonitor" == e.subject) return b(e.payload[0], t), true;
        if ("getMonitorComparison" == e.subject) return ye(t), true;
        if ("getAlerts" == e.subject) return chrome.storage.local.get({
            alerts: []
        }, (function(r) {
            var o = e.payload[0], n = [];
            if (n.push(true), n.push(""), n.push(r.alerts), t(n), o && o.markAsRead) for (let e = 0; e < r.alerts.length; e++) {
                r.alerts[e].status = "SEEN";
            }
            ge(r, true);
        })), true;
        if ("removeUsersFromMonitor" == e.subject) return le(e.payload[0], t), true;
        if ("resetUsersFromMonitor" == e.subject) return P(e.payload[0], t), true;
        if ("removeAlerts" == e.subject) return ue(e.payload[0], t), true;
    }
}

function ue(e, r) {
    Array.isArray(e) && (e = new Set(e)), chrome.storage.local.get({
        alerts: []
    }, (function(t) {
        if (t.alerts && Array.isArray(t.alerts)) for (let r = 0; r < t.alerts.length; r++) {
            const o = t.alerts[r];
            o.id && e.has(o.id) && (t.alerts.splice(r, 1), r--);
        }
        chrome.storage.local.set(t, (function() {}));
        r([ true, "" ]);
    }));
}

function le(e, r) {
    e && Array.isArray(e) ? chrome.storage.local.get({
        monitoredUsers: {}
    }, (function(t) {
        for (let r = 0; r < e.length; r++) {
            const o = e[r];
            t.monitoredUsers[o] && delete t.monitoredUsers[o];
        }
        Array.isArray(t.monitoredUsers) && t.monitoredUsers.length <= 0 && (t.monitoredUsers = {}), 
        chrome.storage.local.set(t, (function() {
            r([ true, "" ]);
        }));
    })) : r([ false, "Array of user id's needed" ]);
}

function P(e, r) {
    chrome.storage.local.get({
        monitoredUsers: {}
    }, (function(t) {
        s.us(e, xt, $e, navigator.userAgent, (function(e, o, n) {
            if (e) {
                var i = new Date;
                for (const e in n) if (n.hasOwnProperty(e)) {
                    var a = n[e];
                    if ((a = me(a)).error) continue;
                    a.fetchedAtPrecise = i.getTime(), t.monitoredUsers[e].comparisonDateData = a;
                }
                chrome.storage.local.set(t, (function() {})), r([ e = true, o, resp ]);
            } else resp = [], r([ e, o, resp ]);
        }));
    }));
}

function b(e, r) {
    var t = true, o = "";
    e = me(e), chrome.storage.local.get({
        monitoredUsers: {}
    }, (function(n) {
        if (Array.isArray(n.monitoredUsers) && (n.monitoredUsers = {}), Object.keys(n.monitoredUsers).length > Se) r([ t = false, o = `You have reached the limit of ${Se} monitored users` ]); else {
            var i;
            for (const r in n.monitoredUsers) {
                const t = n.monitoredUsers[r];
                if (n.monitoredUsers.hasOwnProperty(r) && e.id == r) {
                    i = t;
                    break;
                }
            }
            i ? r([ t = false, o = "User already exists" ]) : (e = me(e), n.monitoredUsers[e.id] = {}, 
            n.monitoredUsers[e.id].comparisonDateData = e, n.monitoredUsers[e.id].lastFetchedData = e, 
            t = true, o = "", chrome.storage.local.set(n, (function() {
                r([ t, o ]);
            })));
        }
    }));
}

function me(e) {
    if ("object" == typeof e && 0 == Object.keys(e).length) return {
        error: "Json was empty"
    };
    if ("object" != typeof e) return {
        error: "userJson is not a JSON object"
    };
    if (!e.id || !e.username) return {
        error: "Missing ID or username"
    };
    var r = {
        id: e.id,
        name: e.name,
        username: e.username,
        avatar: e.avatar || "",
        avatarThumbs: e.avatarThumbs || "",
        currentSubscribePrice: e.currentSubscribePrice || 0,
        price: e.subscribePrice || 0,
        subscribePrice: e.subscribePrice || 0,
        joinDate: e.joinDate,
        photosCount: e.photosCount || 0,
        videosCount: e.videosCount || 0,
        audiosCount: e.audiosCount || 0,
        rawAbout: e.rawAbout || "",
        promotion: e.promotion,
        fetchedAtPrecise: e.fetchedAtPrecise || ""
    };
    if (!e.promotion && e.promotions && Array.isArray(e.promotions)) {
        var t, o = new Date;
        try {
            for (let n = 0; n < e.promotions.length; n++) {
                const i = e.promotions[n];
                t = false, i.finishedAt && (promotionExpireDate = new Date("finishedAt"), (o > promotionExpireDate || e.subscribeCounts && e.subscribeCounts <= 0) && (t = true)), 
                t || (r.promotion = i);
            }
        } catch (e) {}
    }
    return r;
}

function ve() {
    if (Xt) try {
        chrome.storage.local.get({
            monitoredUsers: {},
            alerts: []
        }, (function(e) {
            var r = e.monitoredUsers, t = [];
            for (const e in r) {
                var o = e;
                t.push(o);
            }
            s.us(t, xt, $e, navigator.userAgent, (function(r, t, o) {
                var n = [], i = [];
                if (r) {
                    var a = new Date;
                    for (const r in o) if (o.hasOwnProperty(r)) {
                        var c = o[r];
                        if ((c = me(c)).error || !c.id || !c.username) continue;
                        c.fetchedAtPrecise = a.getTime(), i = he(e.monitoredUsers[r].lastFetchedData, c), 
                        n = n.concat(i), e.monitoredUsers[r].lastFetchedData = c;
                    }
                    n.length > 0 && (e.alerts = n.concat(e.alerts)), ge(e, true, (function() {
                        de();
                    }));
                }
            }));
        }));
    } catch (e) {}
}

function he(e, r) {
    if (!(e.id && e.username && r.id && r.username)) return [];
    var t, o = {
        id: "",
        avatar: e.avatarThumbs && e.avatarThumbs.c144 || e.avatarThumbs && fetchedData.avatarThumbs.c50 || e.avatar || "../images/no_picture_available.jpg",
        avatarThumb: e.avatarThumbs && e.avatarThumbs.c144 || e.avatarThumbs && fetchedData.avatarThumbs.c50 || e.avatar || "../images/no_picture_available.jpg",
        userId: r.id,
        username: r.username,
        name: r.name,
        fetchedAtPrecise: (new Date).getTime(),
        status: "NEW",
        message: "",
        var1: "",
        var2: "",
        var3: "",
        var4: "",
        value1: "",
        value2: "",
        value3: "",
        value4: ""
    }, n = [];
    try {
        e.price != r.price && (t = {}, (t = JSON.parse(JSON.stringify(o))).var1 = "price", 
        t.value1 = e.price, t.var2 = "price", t.value2 = r.price, e.price < r.price ? t.message = `Price increased from $${e.price} to $${r.price}` : t.message = `Price decreased from $${e.price} to $${r.price}`, 
        t.id = r.id + (new Date).getDate(), n.push(t)), e.promotion && e.promotion.price && e.promotion.canClaim && !r.promotion && (t = {}, 
        (t = JSON.parse(JSON.stringify(o))).var1 = "promotion", t.value1 = e.promotion.price, 
        t.var2 = "promotion", t.value2 = "0", t.message = `Promotion is over! (was $${e.promotion.price}). Current price: $${e.price}`, 
        t.id = r.id + (new Date).getDate(), n.push(t)), r.promotion && r.promotion.price && r.promotion.canClaim && !e.promotion && (t = {}, 
        (t = JSON.parse(JSON.stringify(o))).var1 = "promotion", t.value1 = "0", t.var2 = "promotion", 
        t.value2 = r.promotion.price, t.message = `Has an active promotion! Regular price $${e.price}, Promotion price: $${r.promotion.price}`, 
        t.id = r.id + (new Date).getDate(), n.push(t));
    } catch (e) {}
    return n;
}

function de() {
    chrome.storage.local.get({
        alerts: []
    }, (function(e) {
        try {
            if (e.alerts && Array.isArray(e.alerts)) {
                var r = new Date;
                for (let t = 0; t < e.alerts.length; t++) {
                    const o = e.alerts[t];
                    o.id && o.fetchedAtPrecise && pe(r, new Date(o.fetchedAtPrecise)) >= Fe && "SEEN" == o.status && (e.alerts.splice(t, 1), 
                    t--);
                }
            }
            chrome.storage.local.set(e, (function() {}));
        } catch (e) {}
    }));
}

function pe(e, r) {
    const t = Math.abs(e - r);
    return Math.abs(Math.trunc(t / 86400000));
}

function ye(e) {
    chrome.storage.local.get({
        monitoredUsers: {}
    }, (function(r) {
        var t = r.monitoredUsers, o = [];
        for (const e in t) {
            var n = e;
            o.push(n);
        }
        s.us(o, xt, $e, navigator.userAgent, (function(r, o, n) {
            if (r) {
                var i = {}, a = [], c = new Date;
                for (const e in n) if (n.hasOwnProperty(e)) {
                    var s = n[e];
                    if ((s = me(s)).error) continue;
                    s.fetchedAtPrecise = c.getTime(), (i = new Object)[e] = {}, i[e].stored = t[e].comparisonDateData, 
                    i[e].fetched = s, a.push(i);
                }
                e([ r = true, o, a ]);
            } else e([ r, o, a = [] ]);
        }));
    }));
}

function ge(e, r, t) {
    chrome.storage.local.set(e, (function() {
        if (r && e.alerts) {
            var o = 0;
            for (let r = 0; r < e.alerts.length; r++) {
                "NEW" == e.alerts[r].status.toUpperCase() && o++;
            }
            Ne = o, chrome.browserAction.setBadgeBackgroundColor({
                color: "red"
            }), o > 0 ? chrome.browserAction.setBadgeText({
                text: o.toString()
            }) : chrome.browserAction.setBadgeText({
                text: ""
            });
        }
        t instanceof Function && t();
    }));
}

function we(e, r, t) {
    if ("downloadFile" == e.subject) {
        var o = e.payload[0], n = e.payload[1], i = e.payload[2], a = o.substring(o.lastIndexOf("/") + 1, o.lastIndexOf("?") + 0);
        return ae(chrome.downloads, o, n, i, a), t && t instanceof Function && t(), true;
    }
    if ("massDownloadFiles" == e.subject) {
        ie(e.payload), t instanceof Function && t(resp);
    } else {
        if ("getSession" == e.subject) return je(0, (function(e, r, o) {
            if (t && t instanceof Function) {
                var n = {
                    imLoggedIn: Xt,
                    sessCookie: $e,
                    appToken: xt
                };
                chrome.storage.sync.get({
                    dateBeforeFilename: false,
                    chatsSeparateFolder: false,
                    storiesSeparateFolder: false
                }, (function(e) {
                    n.settings = e, t(n);
                }));
            }
        })), true;
        if ("getUserList" == e.subject) {
            var c = Ae();
            t([ De, c ]);
        } else if ("newSubscription" == e.subject) {
            var s = e.payload[0], f = e.payload[1], u = e.payload[2];
            t(), se(s, f, u);
        } else "newUnsubscription" == e.subject ? (t(), ce(e.payload[0])) : "downloadFiles" == e.subject && (t(), 
        oe(e.payload[0]));
    }
}

function Ae() {
    var e = [];
    if (De) for (let r = 0; r < Ue.length; r++) {
        const t = Ue[r];
        try {
            e.push(t.Nt());
        } catch (e) {}
    }
    return e;
}

function U() {
    if (Xt) if ($e && ke && xt) {
        var e = [];
        s.rt($e, ke, xt, (function(r) {
            if (Array.isArray(r)) {
                for (let t = 0; t < r.length; t++) {
                    const o = r[t];
                    e.push(o.St()), s.ht(Ue, o), De = true;
                }
                Promise.all(e).then(e => {});
            }
        }));
    } else setTimeout(() => {
        U();
    }, 2000);
}

je(0, (function() {})), chrome.webRequest.onBeforeSendHeaders.addListener((function(e) {
    var r = new URL(e.url);
    xt = r.searchParams.get("app-token");
}), {
    urls: [ "*://*.onlyfans.com/*" ],
    types: [ "xmlhttprequest" ]
}, [ "requestHeaders" ]), chrome.runtime.onMessage.addListener((e, r, t) => ("background" == !e.to || ("content" === e.from ? we(e, r, t) : "popup" == e.from && kt(e, r, t)), 
true));

var Ue = [], be = 5, Fe = 1, Se = 100, De = false, Xt = false, xt = "", $e = "", ke = navigator.userAgent, Ne = 0;

function Me() {
    Oe(), chrome.alarms.onAlarm.addListener(Pe);
}

function Oe() {
    var e = {
        delayInMinutes: 1,
        periodInMinutes: be
    };
    chrome.alarms.clear("checkForAlerts"), chrome.alarms.create("checkForAlerts", e);
}

function Pe(e) {
    switch (e.name) {
      case "checkForAlerts":
        ve();
    }
}

function _e() {
    chrome.tabs.query({
        url: "*://*.onlyfans.com/*"
    }, (function(e) {
        for (let r of e) chrome.tabs.reload(r.id);
        Me();
    })), je(0, (function() {
        Xt && U();
    }));
}

function je(e, r) {
    chrome.cookies.getAll({
        url: "https://www.onlyfans.com"
    }, (function(e) {
        var t = false;
        for (let r = 0; r < e.length; r++) {
            var o = e[r];
            "auth_id" == o.name && (t = true, Xt = true), "sess" == o.name && ($e = o.value);
        }
        r instanceof Function && r(Xt, $e, xt), t || (Xt = false);
    })), e > 0 && setTimeout((function() {
        je(e, r);
    }), e);
}

chrome.runtime.onStartup.addListener(Me), chrome.runtime.onInstalled.addListener(_e), 
chrome.cookies.onChanged.addListener((function(e) {
    var r = e.cookie.name, t = e.cookie.value, o = e.cause, n = e.removed;
    "auth_id" != r || !n || "expired_overwrite" != o && "explicit" != o ? "auth_id" != r || n || "explicit" != o || Xt ? "sess" != r || n || ($e = t) : (Xt = true, 
    Ue = [], De = false, je(0, (function(e, r, t) {
        var o = {
            imLoggedIn: e,
            sessCookie: r,
            appToken: t,
            userAgent: navigator.userAgent
        };
        U(), te("logged_in", [ o ], "content");
    }))) : (Xt = false, Ue = [], De = false, te("logged_out", [], "content"));
}));