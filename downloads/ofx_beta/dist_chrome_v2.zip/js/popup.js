function e(t, e, o) {
    var n, a = [];
    for (let o = 0; o < t.length; o++) {
        const i = t[o];
        var c, s;
        (n = new Object).url = i.url, i.type && (c = i.type + "/"), i.subfolder && "" != i.subfolder && (s = i.subfolder + "/"), 
        n.path = e + "/" + (s || "") + (c || "");
        var r = "";
        i.preppend && (r = i.preppend + "_"), n.filename = r + i.url.substring(i.url.lastIndexOf("/") + 1, i.url.lastIndexOf("?") + 0), 
        a.push(n);
    }
    var i = {
        from: "popup",
        to: "background",
        subject: "downloadFiles"
    };
    i.payload = [ a ], chrome.runtime.sendMessage(i, (function() {}));
}

function o(o, n) {
    try {
        var a, c, s, r = [], i = [], u = "";
        if ("posts" == o) a = document.getElementById("postsTable"), u = ""; else if ("chats" == o) a = document.getElementById("chatsTable"), 
        Z.chatsSeparateFolder && (u = "chats"); else if ("stories" == o) a = document.getElementById("storiesTable"), 
        Z.storiesSeparateFolder && (u = "stories"); else {
            if ("purchases" != o) return;
            a = document.getElementById("purchasesTable");
        }
        var d, l = a.tBodies[0].rows;
        for (let t = 0; t < l.length; t++) {
            const e = l[t];
            if (e.getElementsByTagName("input")[0].checked) {
                if (d = e.dataset, c = new Object, c = {
                    url: d.mediasource,
                    type: d.type,
                    id: d.id,
                    postedAt: d.postedat,
                    postedAtPrecise: d.postedatprecise,
                    subfolder: u
                }, Z.dateBeforeFilename) {
                    var h = c.postedAt || void 0;
                    if (h) {
                        var m = h.split("T")[0];
                        m && (c.preppend = m);
                    }
                }
                s = d.username, r.push(c), i.push(c.url);
            }
        }
        r.length <= 0 ? ut("No items selected") : "DOWNLOAD" == n.toUpperCase() ? e(r, s, n) : "CLIPBOARD" == n.toUpperCase() && t.o(i, navigator.clipboard, (function(t) {
            "" == t ? ht("success", "Selected links copied to clipboard!") : ut("Error: " + t);
        }));
    } catch (t) {}
}

function n(e) {
    var o = {
        photo: 0,
        video: 0,
        audio: 0
    };
    try {
        var n, s, r, i = document.getElementById("postsTable");
        i = i.getElementsByTagName("tbody")[0];
        var u, d = e.Wt(), l = -1, h = -1, m = 1;
        for (let p = 0; p < d.length; p++) {
            const g = d[p];
            if (l = g.postId, h = p + 1 < d.length ? d[p + 1].postId : -1, "audio" == g.type ? (n = "../images/audio.png", 
            s = "../images/audio.png") : "photo" == g.type ? (n = g.thumb, s = g.thumb) : "video" == g.type && (n = g.thumb, 
            s = g.preview), g.canViewMedia && g.hasMedia) {
                try {
                    var f = g.type;
                    o[f] || (o[f] = 0), o[f]++;
                } catch (t) {}
                r = t.F(g.postedAt, window.navigator.language);
                var v = g.postedAt, b = c(e.gt(), g.id, n, s, g.url, g.type, g.duration, r, v, g.postedAtPrecise, g.rawText, m);
                i.appendChild(b), 1 == m && (u = b), h == l ? m++ : (a(u, "rowspanColumn", m), m = 1);
            }
        }
    } catch (t) {}
    return o;
}

function a(t, e, o) {
    var n = t.getElementsByClassName(e);
    for (let t = 0; t < n.length; t++) {
        n[t].rowSpan = o;
    }
}

function c(t, e, o, n, a, c, s, r, i, u, d, l) {
    var h, m, f = "";
    "photo" == c ? (h = "photos-svg", m = "Photo") : "video" == c ? (h = "videos-svg", 
    m = "Video", f = `<div class="media-length-container">\n    <label class="media-length">\n    <svg class="g-icon" viewBox="0 2 23 23">\n      <use xlink:href="./icons.svg#videos-svg" />\n    </svg> | ${s = new Date(1000 * s).toISOString().substr(11, 8)}\n    </label>\n  </div>`) : "audio" == c ? (h = "audios-svg", 
    m = "Audio", f = `<div class="media-length-container">\n    <label class="media-length">\n    <svg class="g-icon" viewBox="0 2 23 23">\n      <use xlink:href="./icons.svg#audios-svg" />\n    </svg> | ${s = new Date(1000 * s).toISOString().substr(11, 8)}\n    </label>\n  </div>`) : (h = "posts-svg", 
    m = "Text only");
    var v = document.createElement("tr"), b = `\n  <td><input type="checkbox" id="${e}" name="checkboxDownloadPostMedia"></td>\n  <td>\n    <div class="hover_img div_center">\n      <a href="#"><img class="thumbnail" src="${o}" alt=" " />\n          <span><img class="hidden-image" src="${n}" alt="image"  /></span>\n      </a>\n      ${f}\n    </div>\n\n  </td>\n  <td>\n    <svg class="g-icon" viewBox="0 2 23 23">\n        <use xlink:href="./icons.svg#${h}" />\n        <title>${m}</title>\n    </svg>\n    \n  </td>\n  <td>${r}</td>\n`;
    return 1 == l && (b += `<td rowspan=1 class="rowspanColumn">${d}</td>`), v.innerHTML = b, 
    v.setAttribute("data-username", t), v.setAttribute("data-type", c), v.setAttribute("data-id", e), 
    v.setAttribute("data-mediaSource", a), v.setAttribute("data-date", r), v.setAttribute("data-postedAt", i), 
    v.setAttribute("data-postedAtPrecise", u), v;
}

function r(t, e, o, n, a, c, s, r, i, u, d) {
    var l, h, m = "";
    "photo" == n ? (l = "photos-svg", h = "Photo") : "video" == n ? (l = "videos-svg", 
    h = "Video", m = `<div class="media-length-container">\n    <label class="media-length">\n    <svg class="g-icon" viewBox="0 2 23 23">\n    <use xlink:href="./icons.svg#videos-svg" />\n  </svg> | ${u = new Date(1000 * u).toISOString().substr(11, 8)}\n    </label>\n  </div>`) : "audio" == n ? (l = "audios-svg", 
    h = "Audio") : (l = "posts-svg", h = "Text only");
    var f = `\n  <td><input type="checkbox" id="${t}" name="checkboxDownloadPurchasedMedia"></td>\n  <td>\n    <div class="hover_img div_center">\n      <a href="#"><img class="thumbnail" src="${e}" alt=" " />\n          <span><img class="hidden-image" src="${o}" alt="image"  /></span>\n      </a>\n      ${m}\n    </div>\n\n  </td>\n  <td>\n  <svg class="g-icon" viewBox="0 2 23 23">\n  <use xlink:href="./icons.svg#${l}" />\n  <title>${h}</title>\n</svg>\n  </td>\n  <td>@${d}</td>\n  <td>${a}</td>\n  <td>${r}</td>\n`, v = document.createElement("tr");
    return v.innerHTML = f, v.setAttribute("data-type", n), v.setAttribute("data-id", t), 
    v.setAttribute("data-mediaSource", i), v.setAttribute("data-date", a), v.setAttribute("data-postedAt", c), 
    v.setAttribute("data-postedAtPrecise", s), v.setAttribute("data-username", d), v;
}

function i(t, e, o, n, a, c, s, r, i, u, d, l) {
    var h, m, f = "";
    "photo" == c ? (h = "photos-svg", m = "Photo") : "video" == c ? (h = "videos-svg", 
    m = "Video", f = `<div class="media-length-container">\n    <label class="media-length">\n    <svg class="g-icon" viewBox="0 2 23 23">\n    <use xlink:href="./icons.svg#videos-svg" />\n  </svg> | ${s = new Date(1000 * s).toISOString().substr(11, 8)}\n    </label>\n  </div>`) : "audio" == c ? (h = "audios-svg", 
    m = "Audio") : (h = "posts-svg", m = "Text only");
    var v = `\n  <td><input type="checkbox" id="${e}" name="checkboxDownloadChatMedia"></td>\n  <td>\n    <div class="hover_img div_center">\n      <a href="#"><img class="thumbnail" src="${o}" alt=" " />\n          <span><img class="hidden-image" src="${n}" alt="image"  /></span>\n      </a>\n      ${f}\n    </div>\n\n  </td>\n  <td>\n  <svg class="g-icon" viewBox="0 2 23 23">\n  <use xlink:href="./icons.svg#${h}" />\n  <title>${m}</title>\n</svg>\n  </td>\n  <td>${r}</td>\n  \n`;
    1 == l && (v += `<td rowspan=1 class="rowspanColumn">${d}</td>`);
    var b = document.createElement("tr");
    return b.innerHTML = v, b.setAttribute("data-username", t), b.setAttribute("data-type", c), 
    b.setAttribute("data-id", e), b.setAttribute("data-mediaSource", a), b.setAttribute("data-date", r), 
    b.setAttribute("data-postedAt", i), b.setAttribute("data-postedAtPrecise", u), b;
}

function u(t, e, o, n, a, c, s, r, i, u, d) {
    var l, h, m = "";
    "photo" == c ? (l = "photos-svg", h = "Photo") : "video" == c ? (l = "videos-svg", 
    h = "Video", m = `<div class="media-length-container">\n    <label class="media-length">\n    <svg class="g-icon" viewBox="0 2 23 23">\n    <use xlink:href="./icons.svg#videos-svg" />\n  </svg> | ${s = new Date(1000 * s).toISOString().substr(11, 8)}\n    </label>\n  </div>`) : "audio" == c ? (l = "audios-svg", 
    h = "Audio") : (l = "posts-svg", h = "Text only");
    var f = `\n  <td><input type="checkbox" id="${e}" name="checkboxDownloadStoryMedia"></td>\n  <td>\n    <div class="hover_img div_center">\n      <a href="#"><img class="thumbnail" src="${o}" alt=" " />\n          <span><img class="hidden-image" src="${n}" alt="image"  /></span>\n      </a>\n      ${m}\n    </div>\n\n  </td>\n  <td>\n  <svg class="g-icon" viewBox="0 2 23 23">\n  <use xlink:href="./icons.svg#${l}" />\n  <title>${h}</title>\n</svg>\n  </td>\n  <td>${r}</td>\n`, v = document.createElement("tr");
    return v.innerHTML = f, v.setAttribute("data-username", t), v.setAttribute("data-type", c), 
    v.setAttribute("data-id", e), v.setAttribute("data-mediaSource", a), v.setAttribute("data-date", r), 
    v.setAttribute("data-postedAt", i), v.setAttribute("data-postedAtPrecise", u), v;
}

function d(t, e, o) {
    try {
        dt();
        var a = B();
        a.ds(t, e, o, (function(t, e) {
            try {
                0 == a.Wt().length && ht("error", "Nothing found!"), K("postsTable"), _("checkboxSelectPhotosPosts"), 
                _("checkboxSelectVideosPosts"), _("postsSelectAll"), O("posts", n(a)), document.getElementById("postsTableControlContainer").style.display = "block";
            } catch (t) {} finally {
                lt();
            }
        }));
    } catch (t) {
        lt();
    }
}

function l(e) {
    var o = {
        photo: 0,
        video: 0,
        audio: 0
    };
    try {
        var n, c, s, r = document.getElementById("chatsTable");
        r = r.getElementsByTagName("tbody")[0];
        var u, d = e.Yt(), l = -1, h = -1, m = 1;
        for (let p = 0; p < d.length; p++) {
            const g = d[p];
            if (l = g.dmId, h = p + 1 < d.length ? d[p + 1].dmId : -1, "audio" == g.type ? (n = "../images/audio.png", 
            c = "../images/audio.png") : "photo" == g.type ? (n = g.thumb, c = g.thumb) : "video" == g.type && (n = g.thumb, 
            c = g.preview), g.canViewMedia) if (g.hasMedia) {
                try {
                    var f = g.type;
                    o[f] || (o[f] = 0), o[f]++;
                } catch (t) {}
                s = t.F(g.postedAt, window.navigator.language);
                var v = g.postedAt, b = i(e.gt(), g.id, n, c, g.url, g.type, g.duration, s, v, g.postedAtPrecise, g.rawText, m);
                r.appendChild(b), 1 == m && (u = b), h == l ? m++ : (a(u, "rowspanColumn", m), m = 1);
            } else n = "../images/nomedia.png", c = "../images/nomedia.png";
        }
    } catch (t) {}
    return o;
}

function h(e) {
    var o = {
        photo: 0,
        video: 0,
        audio: 0
    };
    try {
        var n, a, c, s = document.getElementById("storiesTable");
        s = s.getElementsByTagName("tbody")[0];
        var r = e.qt();
        for (let h = 0; h < r.length; h++) {
            const m = r[h];
            "audio" == m.type ? (n = "../images/audio.png", a = "../images/audio.png") : "photo" == m.type ? (n = m.thumb, 
            a = m.thumb) : "video" == m.type && (n = m.thumb, a = m.preview);
            try {
                var i = m.type;
                o[i] || (o[i] = 0), o[i]++;
            } catch (t) {}
            c = t.F(m.postedAt, window.navigator.language);
            var d = m.postedAt, l = u(e.gt(), m.id, n, a, m.url, m.type, m.duration, c, d, m.postedAtPrecise, m.rawText);
            s.appendChild(l);
        }
    } catch (t) {}
    return o;
}

function m(t, e) {
    try {
        dt();
        var o = B();
        o.ps(t, e, (function(t, e) {
            try {
                0 == o.Yt().length && 0 == o.Tt().length && ht("error", "Nothing found!"), K("chatsTable"), 
                _("checkboxSelectPhotosChats"), _("checkboxSelectVideosChats"), _("chatsSelectAll"), 
                O("chats", l(o)), document.getElementById("chatsTableControlContainer").style.display = "block";
            } catch (t) {} finally {
                lt();
            }
        }));
    } catch (t) {
        lt();
    }
}

function f(e) {
    var o = {
        photo: 0,
        video: 0,
        audio: 0
    };
    try {
        var n, a, c, s = document.getElementById("purchasesTable");
        s = s.getElementsByTagName("tbody")[0];
        for (let l = 0; l < e.length; l++) {
            const h = e[l];
            "audio" == h.type ? (n = "../images/audio.png", a = "../images/audio.png") : "photo" == h.type ? (n = h.thumb, 
            a = h.thumb) : "video" == h.type && (n = h.thumb, a = h.preview);
            try {
                var i = h.type;
                o[i] || (o[i] = 0), o[i]++;
            } catch (t) {}
            c = t.F(h.postedAt, window.navigator.language);
            var u = h.postedAt, d = r(h.id, n, a, h.type, c, u, h.postedAtPrecise, h.rawText, h.source.source, h.duration, h.purchasedFrom.username);
            s.appendChild(d);
        }
    } catch (t) {}
    return o;
}

function v(o) {
    var n, a, c = {}, s = [];
    try {
        var r, i = document.getElementById("purchasesTable").tBodies[0].rows;
        for (let t = 0; t < i.length; t++) {
            const e = i[t];
            e.getElementsByTagName("input")[0].checked && (r = e.dataset, new Object, a = {
                url: r.mediasource,
                type: r.type,
                id: r.id,
                postedAt: r.postedat,
                postedAtPrecise: r.postedatprecise
            }, c[n = r.username] || (c[n] = []), c[n].push(a), s.push(a.url));
        }
        if (s.length <= 0) ut("No items selected"); else if ("DOWNLOAD" == o.toUpperCase()) for (const t in c) {
            e(c[t], t);
        } else "CLIPBOARD" == o.toUpperCase() && t.o(s, navigator.clipboard, (function(t) {
            "" == t ? ht("success", "Selected links copied to clipboard!") : ut("Error: " + t);
        }));
    } catch (t) {}
}

function b(t) {
    var e = [];
    dt(), t.length > 0 && "@" == t[0] && (t = t.substring(1)), e.push(t), s.us(e, Q.appToken, Q.cookie, Q.useragent, (function(t, e, o) {
        if (t) {
            var n = o[Object.keys(o)[0]];
            if (n.error) lt(), ut(n.error.message); else {
                var a = new Date;
                n.fetchedAtPrecise = a.getTime();
                var c = {
                    from: "popup",
                    to: "background",
                    subject: "addUserToMonitor"
                };
                c.payload = [ n ], chrome.runtime.sendMessage(c, (function(o) {
                    t = o[0], e = o[1], lt(), t ? (ht("Success", "User added!"), k()) : ut(e);
                }));
            }
        } else lt(), ut(e);
    }));
}

function p() {
    var t = {
        from: "popup",
        to: "background",
        subject: "getAlerts",
        payload: [ {
            markAsRead: true
        } ]
    };
    dt(), chrome.runtime.sendMessage(t, (function(t) {
        var e = t[0], o = t[1], n = t[2];
        try {
            e ? (g(n), 0 == n.length && ht("ERROR", "No alerts found!"), lt()) : (lt(), ut(o));
        } catch (t) {
            lt(), ut(t.toString());
        }
    }));
}

function g(t) {
    var e, o = document.getElementById("alerts-container-table");
    try {
        o = o.getElementsByTagName("tbody")[0], K("alerts-container-table");
        for (let n = 0; n < t.length; n++) {
            e = S(t[n]), o.appendChild(e);
        }
    } catch (t) {
        throw t;
    }
}

function S(e) {
    var o, n;
    try {
        (o = (o = document.getElementsByClassName("alerts-table-row-model")[0]).cloneNode(true)).setAttribute("data-id", e.id), 
        n = t.v(new Date(e.fetchedAtPrecise), true, true, true), o.getElementsByClassName("top-right")[0].textContent = n, 
        o.getElementsByClassName("notification-picture")[0].src = e.avatarThumb || e.avatar || "../images/no_picture_available.jpg", 
        n = e.message, o.getElementsByClassName("notification-text-span")[0].textContent = n, 
        n = `${e.name} (<a target="_blank" href="https://onlyfans.com/${e.username}">@${e.username}</a>)`, 
        o.getElementsByClassName("notification-username")[0].innerHTML = n;
        var a = o.getElementsByClassName("new-alert-badge")[0];
        return a && "NEW" == e.status.toUpperCase() ? a.setAttribute("data-new", "true") : a.setAttribute("data-new", "false"), 
        o.classList.remove("hidden"), o;
    } catch (t) {}
}

function k() {
    var t = {
        from: "popup",
        to: "background",
        subject: "getMonitorComparison"
    };
    dt(), chrome.runtime.sendMessage(t, (function(t) {
        var e = t[0], o = t[1], n = t[2];
        try {
            e ? (w(n), lt()) : (lt(), ut(o));
        } catch (t) {
            lt(), ut(t.toString());
        }
    }));
}

function w(t) {
    var e, o, n = document.getElementById("monitor-container-table");
    try {
        t.sort((function(t, e) {
            if (!("object" == typeof t && "object" == typeof e && Object.keys(t).length > 0 && Object.keys(e).length > 0)) return 0;
            const o = Object.keys(t)[0], n = Object.keys(e)[0];
            return t[o].fetched.username < e[n].fetched.username ? -1 : t[o].fetched.username > e[n].fetched.username ? 1 : 0;
        }));
        var a, c = 0, s = n.getElementsByTagName("tbody")[0];
        K("monitor-container-table");
        for (let n = 0; n < t.length; n++) {
            const r = t[n];
            "object" == typeof r && Object.keys(r).length > 0 && (e = r[a = Object.keys(r)[0]].fetched, 
            o = y(r[a].stored, e), s.appendChild(o), c++);
        }
        document.getElementById("monitorTableContainer").getElementsByClassName("monitored-users-amount")[0].textContent = c.toString(), 
        n.setAttribute("data-count", c.toString()), c > 0 && document.getElementById("monitorTableControlContainer").classList.remove("hidden");
    } catch (t) {
        throw t;
    }
}

function y(e, o) {
    var n, a, c, s, r;
    try {
        if ((n = (n = document.getElementsByClassName("monitor-table-row-model")[0]).cloneNode(true)).setAttribute("data-id", o.id), 
        r = "Comparison date: " + (r = t.v(new Date(e.fetchedAtPrecise), true, true, true)), 
        n.getElementsByClassName("top-right")[0].textContent = r, n.getElementsByClassName("notification-picture")[0].src = o.avatarThumbs && o.avatarThumbs.c144 || o.avatarThumbs && o.avatarThumbs.c50 || o.avatar || "../images/no_picture_available.jpg", 
        n.getElementsByClassName("hover")[0].src = o.avatar || o.avatarThumbs && o.avatarThumbs.c50 || o.avatarThumbs && o.avatarThumbs.c144 || "../images/no_picture_available.jpg", 
        2 != (a = n.getElementsByClassName("monitor-table-row")).length) return;
        c = a[0], s = a[1], r = o.photosCount, c.getElementsByClassName("photos-count")[0].textContent = r, 
        r = o.videosCount, c.getElementsByClassName("videos-count")[0].textContent = r, 
        r = o.audiosCount, c.getElementsByClassName("audios-count")[0].textContent = r;
        var i = x(o), u = n.getElementsByClassName("sale-badge")[0];
        return c.getElementsByClassName("subscription-price")[0].textContent = i.price, 
        i.sale ? (u.getElementsByClassName("sale-badge-text")[0].textContent = `SALE ${i.pct}% OFF!`, 
        u.setAttribute("data-sale", "true")) : (c.getElementsByClassName("subscription-price")[0].textContent = i.price, 
        u.setAttribute("data-sale", "false")), r = `${o.name} (<a target="_blank" href="https://onlyfans.com/${o.username}">@${e.username}</a>)`, 
        n.getElementsByClassName("notification-username")[0].innerHTML = r, r = (r = o.photosCount - e.photosCount) > 0 && "+" + r || r, 
        s.getElementsByClassName("photos-count")[0].textContent = r, r = (r = o.videosCount - e.videosCount) > 0 && "+" + r || r, 
        s.getElementsByClassName("videos-count")[0].textContent = r, r = (r = o.audiosCount - e.audiosCount) > 0 && "+" + r || r, 
        s.getElementsByClassName("audios-count")[0].textContent = r, r = (0 == (r = (i.sale && i.salePrice || i.price) - e.subscribePrice) ? "--" : r > 0 && "+" + Math.round(r)) || Math.round(r), 
        s.getElementsByClassName("subscription-price")[0].textContent = r, r = `${o.name} (<a target="_blank" href="https://onlyfans.com/${o.username}">@${e.username}</a>)`, 
        n.getElementsByClassName("notification-username")[0].innerHTML = r, n.classList.remove("hidden"), 
        n;
    } catch (t) {}
}

function x(t) {
    var e = {
        price: "0",
        salePrice: "0",
        pct: "0",
        sale: false
    };
    try {
        if (t.promotion && t.promotion.canClaim) {
            var o = 100 - Math.round(100 * t.promotion.price / t.subscribePrice);
            e.price = t.subscribePrice, e.salePrice = t.promotion.price, e.pct = o, e.sale = true;
        } else e.price = t.subscribePrice, e.pct = "0", e.sale = false;
    } catch (t) {
        return e;
    }
    return e;
}

function C() {
    var t = T("monitor-container-table", 0);
    if (t.length <= 0) ht("ERROR", "No user selected!"); else {
        var e = {
            from: "popup",
            to: "background",
            subject: "removeUsersFromMonitor",
            payload: []
        };
        e.payload.push(t), dt(), chrome.runtime.sendMessage(e, (function(t) {
            var e = t[0], o = t[1];
            lt(), e ? (k(), ht("SUCCESS", "Users removed successfully!")) : ht("ERROR", o);
        }));
    }
}

function P() {
    var t = T("monitor-container-table", 0);
    if (t.length <= 0) ht("ERROR", "No user selected!"); else {
        var e = {
            from: "popup",
            to: "background",
            subject: "resetUsersFromMonitor",
            payload: []
        };
        e.payload.push(t), dt(), chrome.runtime.sendMessage(e, (function(t) {
            var e = t[0], o = t[1];
            lt(), e ? (k(), ht("SUCCESS", "Done!")) : ht("ERROR", o);
        }));
    }
}

function T(t, e) {
    var o = [];
    try {
        var n = document.getElementById(t), a = n && n.rows || void 0;
        for (let t = 0; t < a.length; t++) {
            const n = a[t], c = D(n, e);
            if (c && c.checked) {
                const t = n.getAttribute("data-id");
                t && "" != t && o.push(t);
            }
        }
    } catch (t) {
        return o;
    }
    return o;
}

function D(t, e) {
    const o = t.cells[e];
    var n;
    for (let t = 0; t < o.childNodes.length; t++) {
        const e = o.childNodes[t];
        if ("CHECKBOX" == e.type.toUpperCase()) {
            n = e;
            break;
        }
    }
    return n;
}

function A(t) {
    var e, o, n;
    "MONITOR" == t && (e = "monitor-container-table", o = "checkboxSelectUsersMonitor", 
    n = 0);
    try {
        var a = document.getElementById(o), c = document.getElementById(e), s = c && c.rows || void 0;
        for (let t = 0; t < s.length; t++) {
            const e = D(s[t], n);
            e && (e.checked = a.checked);
        }
    } catch (t) {}
}

function $() {
    try {
        var t = Q.appToken, e = Q.useragent, o = Q.cookie;
        J = [], dt(), document.getElementById("checkboxSelectPhotosPurchases").checked = false, 
        document.getElementById("checkboxSelectVideosPurchases").checked = false, document.getElementById("purchasesSelectAll").checked = false, 
        s.ns(t, o, e, (function(t, e, o) {
            if (t) {
                J = o;
                try {
                    0 == J.length && ht("error", "Nothing found!"), K("purchasesTable"), _("checkboxSelectPhotosPurchases"), 
                    _("checkboxSelectVideosPurchases"), _("purchasesSelectAll"), O("purchases", f(J)), 
                    document.getElementById("purchasesTableControlContainer").style.display = "block";
                } catch (t) {} finally {
                    lt();
                }
            } else J = [];
        }));
    } catch (t) {}
}

function O(t, e) {
    switch (t.toUpperCase()) {
      case "PURCHASES":
        document.getElementById("tablePurchasesPhotosCount").innerText = e.photo, document.getElementById("tablePurchasesVideosCount").innerText = e.video, 
        document.getElementById("tablePurchasesAudiosCount").innerText = e.audio;
        break;

      case "POSTS":
        document.getElementById("tablePostsPhotosCount").innerText = e.photo, document.getElementById("tablePostsVideosCount").innerText = e.video, 
        document.getElementById("tablePostsAudiosCount").innerText = e.audio;
        break;

      case "CHATS":
        document.getElementById("tableChatsPhotosCount").innerText = e.photo, document.getElementById("tableChatsVideosCount").innerText = e.video, 
        document.getElementById("tableChatsAudiosCount").innerText = e.audio;
        break;

      case "STORIES":
        document.getElementById("tableStoriesPhotosCount").innerText = e.photo, document.getElementById("tableStoriesVideosCount").innerText = e.video, 
        document.getElementById("tableStoriesAudiosCount").innerText = e.audio;
    }
}

function F() {
    try {
        dt();
        var t = B();
        t.vs((function(e, o) {
            try {
                0 == t.qt().length && ht("error", "Nothing found!"), K("storiesTable"), _("checkboxSelectPhotosStories"), 
                _("checkboxSelectVideosStories"), _("storiesSelectAll"), O("stories", h(t)), document.getElementById("storiesTableControlContainer").style.display = "block";
            } catch (t) {} finally {
                lt();
            }
        }));
    } catch (t) {
        lt();
    }
}

function U(t) {
    if (Q.imLoggedIn && Q.cookie && Q.useragent && Q.appToken) {
        var e = [];
        try {
            dt("Getting your subscriptions..."), s.rt(Q.cookie, Q.useragent, Q.appToken, (function(o) {
                if (Array.isArray(o)) {
                    for (let t = 0; t < o.length; t++) {
                        const n = o[t];
                        e.push(n.St()), s.ht(q, n);
                    }
                    Promise.all(e).then(e => {
                        try {
                            t(e);
                        } catch (t) {} finally {
                            lt();
                        }
                    });
                } else ut("Error trying to retrieve user list");
            }));
        } catch (t) {
            lt(), ut(t);
        }
    }
}

function M(t) {
    var e = {
        from: "popup",
        to: "background",
        subject: "getSessionParams"
    };
    chrome.runtime.sendMessage(e, (function(e) {
        try {
            var o = e[0];
            Q.cookie = o.sescookie, Q.useragent = o.useragent, Q.appToken = o.appToken, Q.imLoggedIn = o.imLoggedIn, 
            Q.alertsCount = o.alertsCount, Z = o.settings, document.getElementById("checkboxSettingsIncludeDate").checked = Z.dateBeforeFilename, 
            document.getElementById("checkboxSettingsChatsFolder").checked = Z.chatsSeparateFolder, 
            document.getElementById("checkboxSettingsStoriesFolder").checked = Z.storiesSeparateFolder, 
            t instanceof Function && t(Q);
        } catch (t) {}
    }));
}

function V(t) {
    var e = {
        from: "popup",
        to: "background",
        subject: "getUserList",
        payload: []
    };
    chrome.runtime.sendMessage(e, (function(e) {
        q = [];
        var o = e[0], n = e[1];
        if (o) {
            for (let t = 0; t < n.length; t++) {
                const e = n[t];
                var a = s.os(e);
                a.jt() || q.push(a);
            }
            q.sort((function(t, e) {
                return t.gt() < e.gt() ? -1 : t.gt() > e.gt() ? 1 : 0;
            })), t instanceof Function && t([ o, q ]);
        } else t([ o, [] ]);
    }));
}

function B() {
    try {
        var t = document.getElementById("usersSelect"), e = t[t.selectedIndex].value;
        return s.Jt(q, e);
    } catch (t) {
        return;
    }
}

function j(e) {
    return t.F(e, window.navigator.language).split(" ")[0];
}

function R() {
    var t = document.getElementById("userProfilePicture"), o = t.getAttribute("data-download-url"), n = t.getAttribute("data-username");
    if (o && "" != o) {
        new Object;
        e([ {
            url: o + "?",
            type: "",
            id: "profile_picture"
        } ], n, "DOWNLOAD");
    } else ut("No display picture available");
}

function N() {
    var t = B(), e = j(t.Rt());
    K("postsTable"), K("chatsTable"), K("storiesTable"), z({
        joinedAtValue: e,
        postsValue: t.Xt(),
        photosValue: t.Gt(),
        videosValue: t.Kt(),
        audiosValue: t.Qt(),
        archivedValue: t.Zt(),
        hasStoriesValue: t.ss()
    }), H("show"), W("posts"), document.getElementById("postsTableControlContainer").style.display = "none", 
    document.getElementById("chatsTableControlContainer").style.display = "none", document.getElementById("storiesTableControlContainer").style.display = "none";
    var o = document.getElementById("userProfilePicture");
    t.Et() && "" != t.Et() ? o.src = t.Et() : o.src = "../images/no_picture_available.jpg";
    try {
        o.setAttribute("data-download-url", t.Ht() || t.Et() || t.Bt() || o.src), o.setAttribute("data-username", t.gt());
    } catch (t) {}
    document.getElementById("regularPosts").checked = true;
    var n = document.getElementById("customSearch");
    n.checked = true, n.click();
    var a = document.getElementById("customSearchChats");
    a.checked = true, a.click(), _("checkboxSelectPhotosPosts"), _("checkboxSelectVideosPosts"), 
    _("postsSelectAll"), _("checkboxSelectPhotosChats"), _("checkboxSelectPhotosChats"), 
    _("chatsSelectAll"), _("checkboxSelectPhotosStories"), _("checkboxSelectPhotosStories"), 
    _("storiesSelectAll"), _("checkboxSelectPhotosPurchases"), _("checkboxSelectPhotosPurchases"), 
    _("purchasesSelectAll");
}

function _(t) {
    var e = document.getElementById(t);
    e && (e.checked = false);
}

function E(t, e) {
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, (function(o) {
        chrome.tabs.sendMessage(o[0].id, t, (function(t) {
            e(t);
        }));
    }));
}

function L() {
    M((function() {})), at(), I(), V((function(t) {
        q.length > 0 && G(q);
    }));
}

function I() {
    K("postsTable"), K("chatsTable"), K("storiesTable"), K("purchasesTable"), document.getElementById("purchasesTableControlContainer").style.display = "none", 
    G([]), z({
        joinedAtValue: "N/A",
        postsValue: 0,
        photosValue: 0,
        videosValue: 0,
        audiosValue: 0,
        archivedValue: 0,
        hasStoriesValue: "--"
    }), H("hide"), W("topTabContentHome"), W("noTab");
    var t = document.getElementById("userProfilePicture");
    t.src = "../images/no_picture_available.jpg", t.setAttribute("data-username", ""), 
    t.setAttribute("data-download-url", "");
    var e = document.getElementById("alerts-count-badge");
    e && Q.alertsCount && (e.setAttribute("data-count", Q.alertsCount), e.textContent = Q.alertsCount);
}

function W(t) {
    var e = "";
    switch (t) {
      case "posts":
        e = "btnPosts";
        break;

      case "chats":
        e = "btnChats";
        break;

      case "about":
        break;

      case "noTab":
        e = "btnNoTab";
        break;

      case "topTabContentHome":
        e = "topBtnHome";
        break;

      case "topTabContentPurchases":
        e = "topBtnPurchases";
        break;

      case "topTabContentAbout":
        e = "topBtnAbout";
    }
    var o = document.getElementById(e);
    o && o.click();
}

function H(t) {
    Y("buttonGroupWrapper", t), Y("buttonGroupWrapperChats", t);
}

function Y(t, e) {
    var o = document.getElementById(t);
    o && (o.style.display = "hide" === e ? "none" : "block");
}

function z(t) {
    for (var e in t) {
        var o = document.getElementById(e);
        o && (o.innerText = t[e]);
    }
}

function G(e) {
    var o;
    try {
        for (var n = (o = document.getElementById("usersSelect")).getElementsByTagName("option"); n.length > 0; ) n[0].remove();
    } catch (t) {
        return;
    }
    var a = t.$("Select a user", "");
    a.selected = true, a.hidden = true, o.appendChild(a);
    for (let n = 0; n < e.length; n++) {
        const c = e[n];
        (a = t.$(c.yt() + ` (@${c.gt()})`, c.gt())).disabled = false, o.appendChild(a);
    }
}

function K(t) {
    var e = document.getElementById(t);
    try {
        var o = e.getElementsByTagName("tr");
        if (o && o.length > 1) for (;o.length > 1; ) e.deleteRow(1);
    } catch (t) {}
}

function X(t) {
    var e = document.getElementById("screenCoverContainer");
    document.getElementById("coverText").innerText = t, e.style.display = "block";
}

window.Notiflix.Notify.Init({
    position: "right-bottom",
    cssAnimationStyle: "from-left"
}), window.Notiflix.Loading.Init({
    backgroundColor: "rgba(255, 255, 255, 0.7)",
    fontFamily: "Roboto",
    svgSize: "80px",
    messageFontSize: "18px",
    te: "#32c682",
    ee: "#959595"
});

var q = [], J = [], Q = {
    cookie: "",
    useragent: "",
    appToken: "",
    imLoggedIn: false
}, Z = {
    dateBeforeFilename: false,
    chatsSeparateFolder: false,
    storiesSeparateFolder: false
};

function tt(t, e) {
    document.getElementById(t)._flatpickr.setDate(e, true, "Y-m-d");
}

function et() {
    var t = {
        dateBeforeFilename: document.getElementById("checkboxSettingsIncludeDate").checked,
        chatsSeparateFolder: document.getElementById("checkboxSettingsChatsFolder").checked,
        storiesSeparateFolder: document.getElementById("checkboxSettingsStoriesFolder").checked
    }, e = {
        from: "popup",
        to: "background",
        subject: "setSettings",
        payload: []
    };
    e.payload.push(t), dt(), chrome.runtime.sendMessage(e, (function(e) {
        try {
            e && (Z = t);
        } catch (t) {} finally {
            lt();
        }
    }));
}

function ot() {
    var t = document.querySelectorAll("input[type=date]");
    for (let e = 0; e < t.length; e++) {
        const o = t[e];
        window.flatpickr("#" + o.id, {
            altInput: true,
            altFormat: "F j, Y",
            dateFormat: "Y-m-d",
            onChange: function(t, e, o) {}
        }), o._flatpickr.altInput.placeholder = "Select date...";
    }
}

function nt() {
    Q.cookie && Q.useragent && Q.appToken ? (q = [], U((function(t) {
        var e = {
            from: "popup",
            to: "background",
            subject: "setUserList"
        }, o = [];
        for (let t = 0; t < q.length; t++) {
            const e = q[t];
            o.push(e.Nt());
        }
        e.payload = [ o ], chrome.runtime.sendMessage(e, (function() {})), L();
    }))) : ut("Session info missing");
}

function at() {
    document.getElementById("reloadUserList").onclick = function() {
        nt();
    }, document.getElementById("topBtnHome").onclick = function() {
        bt(this), ft("topTabContentHome");
    }, document.getElementById("topBtnPurchases").onclick = function() {
        bt(this), ft("topTabContentPurchases");
    }, document.getElementById("topBtnMonitor").onclick = function() {
        bt(this), ft("topTabContentMonitor");
    }, document.getElementById("topBtnAbout").onclick = function() {
        bt(this), ft("topTabContentAbout");
    }, document.getElementById("topBtnSettings").onclick = function() {
        bt(this), ft("topTabContentSettings");
    }, document.getElementById("topBtnAlerts").onclick = function() {
        bt(this), ft("topTabContentAlerts");
    }, document.getElementById("searchAlerts").onclick = function() {
        p();
    }, document.getElementById("btnPosts").onclick = function() {
        vt(this), mt("tabPosts");
    }, document.getElementById("btnChats").onclick = function() {
        vt(this), mt("tabChats");
    }, document.getElementById("btnStories").onclick = function() {
        vt(this), mt("tabStories");
    }, document.getElementById("btnNoTab").onclick = function() {
        vt(this), mt("tabNoTab");
    }, document.getElementById("usersSelect").addEventListener("change", (function() {
        N();
    })), document.getElementById("profile-picture-download-label").addEventListener("click", (function() {
        R();
    })), document.getElementById("downloadSelectedChatsButton").onclick = function() {
        o("chats", "download");
    }, document.getElementById("copyLinksSelectedChatsButton").onclick = function() {
        o("chats", "clipboard");
    }, document.getElementById("downloadSelectedStoriesButton").onclick = function() {
        o("stories", "download");
    }, document.getElementById("deleteSelectedMonitorButton").onclick = function() {
        C();
    }, document.getElementById("resetSelectedMonitorButton").onclick = function() {
        P();
    }, document.getElementById("copyLinksSelectedStoriesButton").onclick = function() {
        o("stories", "clipboard");
    }, document.getElementById("downloadSelectedPurchasesButton").onclick = function() {
        v("download");
    }, document.getElementById("copyLinksSelectedPurchasesButton").onclick = function() {
        v("clipboard");
    }, document.getElementById("downloadSelectedButton").onclick = function() {
        o("posts", "download");
    }, document.getElementById("copyLinksSelectedButton").onclick = function() {
        o("posts", "clipboard");
    }, document.getElementById("searchStories").onclick = function() {
        F();
    }, document.getElementById("searchPurchases").onclick = function() {
        $();
    }, document.getElementById("searchMonitor").onclick = function() {
        k();
    }, document.getElementById("addUserToMonitor").onclick = function() {
        try {
            var t = document.getElementById("usernameMonitor").value;
            if ("" == (t = t.trim())) return void ut("Username can't be empty");
            document.getElementById("usernameMonitor").value = "", b(t);
        } catch (t) {}
    }, document.getElementById("searchChats").onclick = function() {
        var t = document.getElementById("chatsDateFrom"), e = document.getElementById("chatsDateTo"), o = t.value, n = e.value;
        "" != o && "" != n ? o > n ? ut('"Date from" must be less than "date to"') : m(o, n) : ut('Please select "date from" and "date to"');
    }, document.getElementById("searchPosts").onclick = function() {
        var t = document.getElementById("postsDateFrom"), e = document.getElementById("postsDateTo"), o = t.value, n = e.value;
        if ("" != o && "" != n) if (o > n) ut('"Date from" must be less than "date to"'); else {
            var a = document.getElementsByName("postTypeSearch"), c = "", s = false;
            for (let t = 0; t < a.length; t++) {
                const e = a[t];
                true == e.checked && (c = e.value);
            }
            "regular" == c ? s = false : "archived" == c && (s = true), d(o, n, s);
        } else ut('Please select "date from" and "date to"');
    }, document.getElementById("checkboxSettingsIncludeDate").addEventListener("change", (function() {
        et();
    })), document.getElementById("checkboxSettingsChatsFolder").addEventListener("change", (function() {
        et();
    })), document.getElementById("checkboxSettingsStoriesFolder").addEventListener("change", (function() {
        et();
    })), document.getElementById("dummy").onclick = function() {
        ut("hello");
    }, document.getElementById("purchasesSelectAll").addEventListener("change", (function(t) {
        var e = document.getElementById("checkboxSelectPhotosPurchases"), o = document.getElementById("checkboxSelectVideosPurchases");
        e.checked = t.target.checked, o.checked = t.target.checked;
        for (var n = document.getElementsByName("checkboxDownloadPurchasedMedia"), a = 0; a < n.length; a++) n[a].checked = t.target.checked;
    })), document.getElementById("checkboxSelectPhotosPurchases").addEventListener("change", (function(t) {
        for (var e = document.getElementsByName("checkboxDownloadPurchasedMedia"), o = 0; o < e.length; o++) {
            "photo" == e[o].getAttribute("data-type") && (e[o].checked = t.target.checked);
        }
    })), document.getElementById("checkboxSelectVideosPurchases").addEventListener("change", (function(t) {
        for (var e = document.getElementsByName("checkboxDownloadPurchasedMedia"), o = 0; o < e.length; o++) {
            "video" == e[o].getAttribute("data-type") && (e[o].checked = t.target.checked);
        }
    })), document.getElementById("postsSelectAll").addEventListener("change", (function(t) {
        var e = document.getElementById("checkboxSelectPhotosPosts"), o = document.getElementById("checkboxSelectVideosPosts");
        e.checked = t.target.checked, o.checked = t.target.checked;
        for (var n = document.getElementsByName("checkboxDownloadPostMedia"), a = (B(), 
        0); a < n.length; a++) n[a].checked = t.target.checked;
    })), document.getElementById("checkboxSelectPhotosPosts").addEventListener("change", (function(t) {
        ct("photo", t.target.checked, "checkboxDownloadPostMedia");
    })), document.getElementById("checkboxSelectVideosPosts").addEventListener("change", (function(t) {
        ct("video", t.target.checked, "checkboxDownloadPostMedia");
    })), document.getElementById("chatsSelectAll").addEventListener("change", (function(t) {
        var e = document.getElementById("checkboxSelectPhotosChats"), o = document.getElementById("checkboxSelectVideosChats");
        e.checked = t.target.checked, o.checked = t.target.checked;
        for (var n = document.getElementsByName("checkboxDownloadChatMedia"), a = (B(), 
        0); a < n.length; a++) n[a].checked = t.target.checked;
    })), document.getElementById("checkboxSelectPhotosChats").addEventListener("change", (function(t) {
        st("photo", t.target.checked, "checkboxDownloadChatMedia");
    })), document.getElementById("checkboxSelectVideosChats").addEventListener("change", (function(t) {
        st("video", t.target.checked, "checkboxDownloadChatMedia");
    })), document.getElementById("storiesSelectAll").addEventListener("change", (function(t) {
        var e = document.getElementById("checkboxSelectPhotosStories"), o = document.getElementById("checkboxSelectVideosStories");
        e.checked = t.target.checked, o.checked = t.target.checked;
        for (var n = document.getElementsByName("checkboxDownloadStoryMedia"), a = 0; a < n.length; a++) n[a].checked = t.target.checked;
    })), document.getElementById("checkboxSelectPhotosStories").addEventListener("change", (function(t) {
        rt("photo", t.target.checked, "checkboxDownloadStoryMedia");
    })), document.getElementById("checkboxSelectVideosStories").addEventListener("change", (function(t) {
        rt("video", t.target.checked, "checkboxDownloadStoryMedia");
    })), document.getElementById("checkboxSelectUsersMonitor").addEventListener("change", (function(t) {
        A("MONITOR");
    }));
    var e = document.getElementsByName("searchType");
    for (let o = 0; o < e.length; o++) {
        e[o].addEventListener("click", (function(e) {
            "customSearch" == e.target.id && e.target.checked;
            var o = new Date, n = t.I(new Date);
            switch (e.target.id) {
              case "customSearch":
                tt("postsDateFrom", ""), tt("postsDateTo", n);
                break;

              case "sinceYesterdaySearch":
                o.setDate(o.getDate() - 1), tt("postsDateFrom", t.I(o)), tt("postsDateTo", n);
                break;

              case "lastWeekSearch":
                o.setDate(o.getDate() - 7), tt("postsDateFrom", t.I(o)), tt("postsDateTo", n);
                break;

              case "everythingSearch":
                tt("postsDateFrom", B().Rt()), tt("postsDateTo", n);
            }
        }));
    }
    var n = document.getElementsByName("searchTypeChats");
    for (let e = 0; e < n.length; e++) {
        n[e].addEventListener("click", (function(e) {
            var o = "customSearchChats" == e.target.id && e.target.checked, n = t.I(new Date);
            (tt("postsDateTo", n), o) ? (tt("chatsDateFrom", ""), tt("chatsDateTo", n)) : (tt("chatsDateFrom", B().Rt()), 
            tt("chatsDateTo", n));
        }));
    }
    document.querySelector(".modal"), document.querySelector(".trigger");
    document.querySelector(".close-button").addEventListener("click", it);
}

function ct(t, e, o) {
    for (var n, a = document.getElementsByName(o), c = B(), s = 0; s < a.length; s++) {
        n = a[s].id;
        var r = c.es(n);
        r && r.type == t && (a[s].checked = e);
    }
}

function st(t, e, o) {
    for (var n, a = document.getElementsByName(o), c = B(), s = 0; s < a.length; s++) {
        n = a[s].id;
        var r = c.rs(n);
        r && r.type == t && (a[s].checked = e);
    }
}

function rt(t, e, o) {
    for (var n, a = document.getElementsByName(o), c = B(), s = 0; s < a.length; s++) {
        n = a[s].id;
        var r = c.as(n);
        r && r.type == t && (a[s].checked = e);
    }
}

function it() {
    document.querySelector(".modal").classList.toggle("show-modal");
}

function ut(t) {
    window.Notiflix.Report.Failure("", t, "Ok", (function() {}), {
        width: "360px",
        svgSize: "50px",
        messageFontSize: "2.5rem"
    });
}

function dt(t) {
    var e = "Wait...";
    t && (e = t), window.Notiflix.Loading.Dots(e);
}

function lt() {
    window.Notiflix.Loading.Remove();
}

function ht(t, e) {
    var o = "";
    switch (t.toUpperCase()) {
      case "ERROR":
        o = "Failure";
        break;

      case "SUCCESS":
        o = "Success";
        break;

      case "WARNING":
        o = "Warning";
        break;

      case "INFO":
      default:
        o = "Info";
    }
    window.Notiflix.Notify[o](e);
}

function mt(t) {
    var e = document.getElementsByName("tab-content"), o = document.getElementById(t);
    for (let t = 0; t < e.length; t++) {
        e[t].style.display = "none";
    }
    o.style.display = "block";
}

function ft(t) {
    var e = document.getElementsByName("topTabContent"), o = document.getElementById(t);
    for (let t = 0; t < e.length; t++) {
        e[t].style.display = "none";
    }
    o.style.display = "block";
}

function vt(t) {
    var e = document.getElementsByName("tabButton");
    for (let t = 0; t < e.length; t++) {
        e[t].classList.remove("active");
    }
    t.classList.add("active");
}

function bt(t) {
    var e = document.getElementsByName("topTabButton");
    for (let t = 0; t < e.length; t++) {
        e[t].classList.remove("top-tab-button-active");
    }
    t.classList.add("top-tab-button-active");
}

document.addEventListener("DOMContentLoaded", (function(t) {
    ot(), chrome.tabs.query({
        active: true,
        currentWindow: true
    }, (function(t) {
        t[0].url.includes("onlyfans.com") ? M((function(t) {
            V((function(e) {
                var o = e[0];
                if (o) L(); else if (t.imLoggedIn) {
                    if (!o && t.imLoggedIn) {
                        if (!Q.cookie || !Q.useragent || !Q.appToken) return void X("We are still retrieving info from OnlyFans, please come back in a few seconds...");
                        nt();
                    }
                } else at(), I(), X("You are NOT! logged in to OnlyFans, please sign in and then come back...");
            }));
        })) : (at(), I(), X("Please click on the extension button from the tab where OnlyFans.com is open"));
    }));
})), window.onload = function() {};