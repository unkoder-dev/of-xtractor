function pt(t, n, o) {
    return "content" != t.to || ("popup" === t.from ? kt(t, n, o) : "background" == t.from && gt(t, n, o), 
    true);
}

function gt(t, n, o) {
    var e;
    "logged_out" == t.subject ? (Xt && Dt(), e = "") : "logged_in" == t.subject && (Xt || Lt(), 
    e = ""), o instanceof Function && o(e);
}

function kt(t, n, o) {}

function _t(t, n) {
    var o, e = [];
    for (let r = 0; r < t.length; r++) {
        const u = t[r];
        (o = new Object).url = u.url, u.subfolder && "" != u.subfolder ? o.path = n + "/" + u.subfolder + "/" + u.type + "/" : o.path = n + "/" + u.type + "/";
        var c = "";
        u.preppend && (c = u.preppend + "_"), o.filename = c + u.url.substring(u.url.lastIndexOf("/") + 1, u.url.lastIndexOf("?") + 0), 
        e.push(o);
    }
    var r = {
        from: "content",
        to: "background",
        subject: "downloadFiles"
    };
    r.payload = [ e ], chrome.runtime.sendMessage(r, (function() {}));
}

async function St(t) {
    var n = {
        from: "content",
        to: "background",
        subject: "getSession",
        payload: []
    };
    chrome.runtime.sendMessage(n, (function(n) {
        Xt = n.imLoggedIn, Z = n.settings, t && t instanceof Function && t(Xt, Z);
    }));
}

function yt() {
    if (document.body && document.head) {
        document.body.addEventListener("__HTTPRESPONSE__", t => {
            Tt(t);
        });
        var t = chrome.runtime.getURL("./js/injection.js"), n = document.createElement("script");
        n.src = t, document.head.prepend(n), n.parentNode.removeChild(n);
    }
}

function Et(t) {
    var n = "", o = t.getElementsByClassName("g-user-username");
    return o && o[0] && (n = o[0].innerText) && n.length > 0 && "@" == n.charAt(0) && (n = n.slice(1)), 
    n;
}

function Tt(t) {
    var n = {}, o = t.detail.response, e = t.detail.status, c = t.detail.url;
    xt = new URL(c).searchParams.get("app-token"), c.includes("logout") && 200 == e ? Dt() : c.includes("login") && e >= 200 && e < 400 ? Lt() : Xt && (!c.includes("posts") || c.includes("paid") || c.includes("comments") ? c.includes("posts") && c.includes("paid") && !c.includes("comments") ? setTimeout((function() {
        "OBJECT" == (typeof o).toUpperCase() && o.list && (o = o.list);
        var t = Ot(o);
        St((function(n, o) {
            Ut(t, 1);
        }));
    }), 1000) : c.includes("chats") && c.includes("messages") ? setTimeout((function() {
        var t = [];
        if (o.list && Array.isArray(o.list)) {
            for (let n = 0; n < o.list.length; n++) {
                const e = o.list[n];
                e.media && Array.isArray(e.media) && e.media.length > 0 && false == e.canPurchase && t.push(e);
            }
            St((function(n, o) {
                At(t, 1);
            }));
        }
    }), 1000) : !c.includes("/v2/users") || c.includes("/v2/users/customer") || "object" != typeof o || Array.isArray(o) ? c.includes("/v2/users/customer") : o.id && (200 == e && true == o.subscribedBy ? ((n = {}).from = "content", 
    n.to = "background", n.subject = "newSubscription", n.payload = [ o.id, o.username, o.name ], 
    chrome.runtime.sendMessage(n, (function() {}))) : 200 == e && true != o.subscribedBy && ((n = {}).from = "content", 
    n.to = "background", n.subject = "newUnsubscription", n.payload = [ o.username ], 
    chrome.runtime.sendMessage(n, (function() {})))) : setTimeout((function() {
        "OBJECT" == (typeof o).toUpperCase() && o.list && (o = o.list);
        var t = Ot(o);
        St((function(n, o) {
            Ut(t, 1);
        }));
    }), 500));
}

function Ot(t) {
    Array.isArray(t) || t.constructor != Object || (t = [ t ]);
    var n = {}, o = {};
    for (let c = 0; c < t.length; c++) {
        const r = t[c];
        o = new Object;
        var e = r.author && r.author.id || r.fromUser && r.fromUser.id;
        for (let t = 0; t < r.media.length; t++) {
            const n = r.media[t];
            r.postedAt ? n.postedAt = r.postedAt : r.createdAt && (n.postedAt = r.createdAt);
        }
        o = {
            id: r.id,
            userId: e,
            media: r.media
        }, n[r.id] = o;
    }
    return n;
}

function jt(n, o, e, c) {
    var r, u = "", i = 0, s = false, a = document.createElement("div"), f = [];
    for (let n = 0; n < e.length; n++) {
        const l = e[n];
        if (s = true, l.canView) {
            if (l.url = l.source.source, l.subfolder = c, Z.dateBeforeFilename) {
                var d = l.postedAt || void 0;
                if (d) {
                    var m = d.split("T")[0];
                    m && (l.preppend = m);
                }
            }
            f.push(l.url), u = "Xtract " + l.type, (r = t.L(document, u)).addEventListener("click", (function() {
                _t([ l ], o);
            })), a.appendChild(r), i++;
        }
    }
    s && (n.id = "PROCESSED"), i > 1 && (u = "Xtract ALL", (r = t.L(document, u)).addEventListener("click", (function() {
        _t(e, o);
    })), a.appendChild(r)), i > 0 && (u = "Xtract links", (r = t.L(document, u)).addEventListener("click", (function() {
        Ct(f);
    })), a.appendChild(r)), n.appendChild(a);
}

function wt(t, n) {
    try {
        var o = document.getElementById("ofx_snackbar");
        o.innerText = t;
        var e = "";
        e = "SUCCESS" == n.toUpperCase() ? "show-success" : "show-error", o.className = e, 
        setTimeout((function() {
            o.className = o.className.replace(e, "");
        }), 3000);
    } catch (t) {}
}

function Ct(n) {
    t.o(n, navigator.clipboard, (function(t) {
        "" == t ? wt("Links copied to clipboard!", "success") : wt("Couldn't copy links to clipboard :(", "error");
    }));
}

function Ut(t, n) {
    if (!(n > 50)) try {
        var o, e, c = document.getElementsByClassName("b-post");
        if (c && c.length > 0) {
            for (let n = 0; n < c.length; n++) {
                const u = c[n];
                if ("PROCESSED" != u.id) if (e = u.id.split("_")[1], o = Et(u), t[e] && t[e].media) {
                    var r = t[e].media;
                    o && r && r.length > 0 && jt(u, o, r, ""), delete t[e];
                } else delete t[e];
            }
            Object.keys(t).length > 0 && setTimeout((function() {
                n++, Ut(t, n);
            }), 1500);
        } else "loading" == document.readyState && setTimeout((function() {
            n++, Ut(t, n);
        }), 1500);
    } catch (t) {}
}

function Pt(t, n) {
    var o = false, e = [], c = -1;
    try {
        for (let u = 0; u < t.length; u++) {
            const i = t[u];
            var r = i.media;
            for (let t = 0; t < r.length; t++) {
                const e = r[t];
                e.preview != n && e.squarePreview != n && e.thumb != n && e.src != n || (o = true), 
                i.createdAt ? e.postedAt = i.createdAt : i.postedAt && (e.postedAt = i.postedAt);
            }
            if (o) {
                e = r, c = u;
                break;
            }
        }
    } catch (t) {}
    return [ c, e ];
}

function Rt() {
    var t = document.getElementById("chatUrl");
    if (t && t.href) {
        var n = t.href.split("/");
        return n.length > 0 ? n[n.length - 1] : "unknown_user";
    }
}

function At(t, n) {
    if (!(n > 50)) {
        var o = "";
        Z && Z.chatsSeparateFolder && (o = "chats");
        try {
            var e, c = document.getElementsByClassName("b-chat__message__media-wrapper");
            if (c && c.length > 0) {
                for (let n = 0; n < c.length; n++) {
                    const f = c[n];
                    if ("PROCESSED" != f.id) {
                        var r = f.getElementsByTagName("img");
                        (!r || r.length <= 0) && (r = f.getElementsByTagName("source"));
                        var u = "", i = [], s = -1, a = [];
                        r && r.length > 0 && (u = r[0].src, s = (i = Pt(t, u))[0], a = i[1]), e = Rt(), 
                        !a || a.length <= 0 ? (f.id = "PROCESSED") : (jt(f, e, a, o), t.splice(s, 1));
                    }
                }
                t.length > 0 && setTimeout((function() {
                    n++, At(t, n);
                }), 1500);
            } else "loading" == document.readyState && setTimeout((function() {
                n++, At(t, n);
            }), 1500);
        } catch (t) {}
    }
}

function Dt() {
    Xt = false, xt = "", Ft = [], _users = [];
}

function Lt() {
    Xt = true, xt = "", Ft = [], St();
}

chrome.runtime.onMessage.addListener(pt);

var Ft = [], Xt = false, Z = {}, xt = "";

document.addEventListener("DOMContentLoaded", (function(t) {
    St(), yt();
    var n = document.createElement("div");
    n.setAttribute("id", "ofx_snackbar"), n.innerText = "", document.body.appendChild(n);
}));